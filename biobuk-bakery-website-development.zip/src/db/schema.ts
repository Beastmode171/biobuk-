import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  basePrice: integer("base_price").notNull(),
  imageUrl: text("image_url").notNull(),
  badge: text("badge").default("Artisanal"),
  servingsInfo: text("servings_info").notNull(),
  leadTime: text("lead_time").notNull(),
  flavors: text("flavors").notNull(),
  featured: boolean("featured").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderReference: text("order_reference").notNull().unique(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerEmail: text("customer_email"),
  productId: integer("product_id"),
  productName: text("product_name").notNull(),
  productCategory: text("product_category").notNull(),
  cakeSize: text("cake_size").notNull(),
  flavorChoice: text("flavor_choice").notNull(),
  quantity: integer("quantity").default(1).notNull(),
  fulfillmentType: text("fulfillment_type").notNull(), // "Pickup" | "Delivery"
  deliveryAddress: text("delivery_address"),
  preferredDate: text("preferred_date").notNull(),
  preferredTime: text("preferred_time").default("12:00 PM"),
  specialInstructions: text("special_instructions"),
  unitPrice: integer("unit_price").notNull(),
  deliveryFee: integer("delivery_fee").default(0).notNull(),
  totalPrice: integer("total_price").notNull(),
  status: text("status").default("Received").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  clientName: text("client_name").notNull(),
  occasion: text("occasion").notNull(),
  rating: integer("rating").default(5).notNull(),
  comment: text("comment").notNull(),
  productOrdered: text("product_ordered").notNull(),
  verified: boolean("verified").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type NewOrder = typeof orders.$inferInsert;
export type Testimonial = typeof testimonials.$inferSelect;
export type ContactMessage = typeof contactMessages.$inferSelect;
