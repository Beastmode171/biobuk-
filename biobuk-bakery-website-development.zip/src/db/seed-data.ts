import { db, pool } from "@/db";
import { products, testimonials, orders } from "@/db/schema";
import { count } from "drizzle-orm";

export const INITIAL_PRODUCTS = [
  {
    name: "Rosé Chantilly Lambeth Birthday Cake",
    slug: "rose-chantilly-lambeth-birthday-cake",
    category: "Birthday cakes",
    description:
      "Silky Madagascar vanilla sponge layered with raspberry rosewater compote, finished in vintage Lambeth-style blush pink buttercream piping, French macarons, and 24k edible gold pearls.",
    basePrice: 85,
    imageUrl: "/images/birthday-cake.jpg",
    badge: "Bestseller",
    servingsInfo: "Serves 12–45 guests",
    leadTime: "48h Notice",
    flavors: "Madagascar Vanilla & Raspberry, Red Velvet Crème, Salted Caramel Praline",
    featured: true,
  },
  {
    name: "Jardin de Peony Three-Tier Wedding Cake",
    slug: "jardin-de-peony-wedding-cake",
    category: "Wedding cakes",
    description:
      "An architectural three-tier heirloom wedding masterpiece cloaked in warm ivory Swiss meringue and soft blush fondant, adorned with hand-sculpted sugar peonies and delicate pearl piping.",
    basePrice: 420,
    imageUrl: "/images/wedding-cake.jpg",
    badge: "Haute Couture",
    servingsInfo: "Serves 80–150 guests",
    leadTime: "2 Weeks Notice",
    flavors: "Champagne Strawberry, Lemon Elderflower, Belgian White Chocolate Almond",
    featured: true,
  },
  {
    name: "Amour Vintage Heart Anniversary Cake",
    slug: "amour-vintage-heart-anniversary-cake",
    category: "Anniversary cakes",
    description:
      "Romantic heart-silhouette celebration cake crafted with velvety cream cheese mousseline, ruffled blush buttercream ribbons, dried Damascus rose petals, and fresh ruby berries.",
    basePrice: 95,
    imageUrl: "/images/anniversary-cake.jpg",
    badge: "Signature Romance",
    servingsInfo: "Serves 10–25 guests",
    leadTime: "48h Notice",
    flavors: "Velvet Rose & Berry, Dark Ganache Truffle, Pistachio Blossom",
    featured: true,
  },
  {
    name: "Le Petit Salon Artisanal Cupcake Couture Box",
    slug: "le-petit-salon-cupcake-box",
    category: "Cupcakes",
    description:
      "Curated assortment of moist crumb cupcakes crowned with high-swirl Chantilly cream, dusty rose raspberry buttercream, and espresso ganache, garnished with gold leaf and berries.",
    basePrice: 38,
    imageUrl: "/images/cupcakes.jpg",
    badge: "Gift Favorite",
    servingsInfo: "Box of 6, 12, or 24",
    leadTime: "Same-Day / 24h",
    flavors: "Vanilla Bean Berry, Rosewater Pistachio, Double Espresso Cocoa",
    featured: true,
  },
  {
    name: "Brioche Rose & Belgian Truffle Doughnuts",
    slug: "brioche-rose-belgian-truffle-doughnuts",
    category: "Doughnuts",
    description:
      "48-hour cold-fermented pillow-soft brioche doughnuts filled with Madagascar vanilla diplomat cream and glazed in glossy rosewater blush, pistachio dust, and dark Belgian chocolate.",
    basePrice: 32,
    imageUrl: "/images/doughnuts.jpg",
    badge: "Fresh Daily",
    servingsInfo: "Box of 6 or 12",
    leadTime: "Same-Day Available",
    flavors: "Rosewater Glaze, Vanilla Bean Crème Brûlée, Dark Espresso Drizzle",
    featured: true,
  },
  {
    name: "Royal Soirée Gourmet Small Chops Platter",
    slug: "royal-soiree-small-chops-platter",
    category: "Small chops",
    description:
      "Elevated celebration finger-food platter featuring flaky spiced beef samosas, crispy vegetable spring rolls, golden honey-glazed puff-puff, and peppered cocktail bites with house dips.",
    basePrice: 55,
    imageUrl: "/images/small-chops.jpg",
    badge: "Party Essential",
    servingsInfo: "Platter for 10–30 guests",
    leadTime: "24h Notice",
    flavors: "Classic Savory Platter, VIP Peppered Fiesta, Grand Event Assortment",
    featured: true,
  },
  {
    name: "Parisian Morning Viennoiserie & Pastry Box",
    slug: "parisian-morning-pastry-box",
    category: "Pastries",
    description:
      "Hand-laminated French cultured butter croissants, pain au chocolat, raspberry custard danishes, and caramelized mille-feuille baked to golden, shattering-crisp perfection.",
    basePrice: 42,
    imageUrl: "/images/pastries.jpg",
    badge: "Artisanal",
    servingsInfo: "Assortment of 8 or 16",
    leadTime: "Same-Day Available",
    flavors: "Isigny Butter Croissant, Raspberry Crème Danish, Pain au Chocolat",
    featured: true,
  },
  {
    name: "L'Atelier Bespoke Sculptural Custom Cake",
    slug: "latelier-bespoke-custom-cake",
    category: "Custom cakes",
    description:
      "One-of-a-kind edible art tailored to your theme and color story. Hand-painted palette-knife buttercream florals, custom wafer-paper sails, and bespoke flavor pairings.",
    basePrice: 135,
    imageUrl: "/images/custom-cake.jpg",
    badge: "Bespoke Design",
    servingsInfo: "Custom 1 to 4 Tiers",
    leadTime: "72h Notice",
    flavors: "Custom Multi-Tier Tasting, Hazelnut Praline Feuilletine, Passionfruit Mango",
    featured: true,
  },
];

export const INITIAL_TESTIMONIALS = [
  {
    clientName: "Chidinma & Tunde Adebayo",
    occasion: "Luxury Wedding Reception",
    rating: 5,
    comment:
      "BIOBUK created our three-tier Jardin de Peony wedding cake and 200 small chops platters. Every single guest asked who our pâtissier was—it looked like a sculpture from Paris and tasted heavenly!",
    productOrdered: "Jardin de Peony Three-Tier Wedding Cake",
    verified: true,
  },
  {
    clientName: "Amara Nwosu",
    occasion: "30th Milestone Birthday",
    rating: 5,
    comment:
      "The Rosé Chantilly Lambeth cake was the centerpiece of my dinner party. The blush pink piping was flawless, not overly sweet, and ordering via the website straight to WhatsApp took less than two minutes.",
    productOrdered: "Rosé Chantilly Lambeth Birthday Cake",
    verified: true,
  },
  {
    clientName: "Elena Rostova",
    occasion: "Corporate Client Gifting",
    rating: 5,
    comment:
      "We order BIOBUK's Parisian Pastry Boxes and Artisanal Cupcakes every Friday for our executive studio. The packaging, punctuality, and flaky butter layers are unmatched.",
    productOrdered: "Le Petit Salon Artisanal Cupcake Couture Box",
    verified: true,
  },
  {
    clientName: "David & Sophia Mensah",
    occasion: "5th Wedding Anniversary",
    rating: 5,
    comment:
      "Ordered the Amour Vintage Heart Anniversary Cake with a custom inscription. The velvet rose and berry filling was unforgettable. Truly the finest bakery experience we've ever had.",
    productOrdered: "Amour Vintage Heart Anniversary Cake",
    verified: true,
  },
];

export const GALLERY_ITEMS = [
  {
    id: 1,
    title: "La Vie en Rose Two-Tier Atelier Cake",
    category: "Wedding cakes",
    caption: "Handcrafted sugar roses, 24k gold leaf & raspberry Chantilly",
    imageUrl: "/images/hero-cake.jpg",
    aspect: "tall",
  },
  {
    id: 2,
    title: "Vintage Lambeth Rosé Celebration",
    category: "Birthday cakes",
    caption: "French macarons, strawberry crowns & pearl piping",
    imageUrl: "/images/birthday-cake.jpg",
    aspect: "square",
  },
  {
    id: 3,
    title: "Jardin de Peony Grand Three-Tier",
    category: "Wedding cakes",
    caption: "Cascading sugar peonies on warm ivory Swiss meringue",
    imageUrl: "/images/wedding-cake.jpg",
    aspect: "tall",
  },
  {
    id: 4,
    title: "Amour Heart Ruffle Cake",
    category: "Anniversary cakes",
    caption: "Damascus rose petals & ruby berry compote",
    imageUrl: "/images/anniversary-cake.jpg",
    aspect: "square",
  },
  {
    id: 5,
    title: "Couture Swirl Cupcake Collection",
    category: "Cupcakes",
    caption: "Madagascar vanilla bean & dusty rose buttercream",
    imageUrl: "/images/cupcakes.jpg",
    aspect: "square",
  },
  {
    id: 6,
    title: "Rosewater & Espresso Brioche Doughnuts",
    category: "Doughnuts",
    caption: "Cold-fermented brioche with diplomat cream filling",
    imageUrl: "/images/doughnuts.jpg",
    aspect: "wide",
  },
  {
    id: 7,
    title: "Royal Soirée Small Chops Platter",
    category: "Small chops",
    caption: "Golden samosas, spring rolls & honeyed puff-puff",
    imageUrl: "/images/small-chops.jpg",
    aspect: "square",
  },
  {
    id: 8,
    title: "Laminated French Butter Viennoiserie",
    category: "Pastries",
    caption: "Croissants, pain au chocolat & berry custard danishes",
    imageUrl: "/images/pastries.jpg",
    aspect: "square",
  },
  {
    id: 9,
    title: "Palette-Knife Botanical Custom Tier",
    category: "Custom cakes",
    caption: "Bespoke hand-painted buttercream floral reliefs",
    imageUrl: "/images/custom-cake.jpg",
    aspect: "tall",
  },
];

let initialized = false;

export async function ensureSeeded() {
  if (initialized) return;

  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        base_price INTEGER NOT NULL,
        image_url TEXT NOT NULL,
        badge TEXT DEFAULT 'Artisanal',
        servings_info TEXT NOT NULL,
        lead_time TEXT NOT NULL,
        flavors TEXT NOT NULL,
        featured BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        order_reference TEXT NOT NULL UNIQUE,
        customer_name TEXT NOT NULL,
        customer_phone TEXT NOT NULL,
        customer_email TEXT,
        product_id INTEGER,
        product_name TEXT NOT NULL,
        product_category TEXT NOT NULL,
        cake_size TEXT NOT NULL,
        flavor_choice TEXT NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        fulfillment_type TEXT NOT NULL,
        delivery_address TEXT,
        preferred_date TEXT NOT NULL,
        preferred_time TEXT DEFAULT '12:00 PM',
        special_instructions TEXT,
        unit_price INTEGER NOT NULL,
        delivery_fee INTEGER NOT NULL DEFAULT 0,
        total_price INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'Received',
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS testimonials (
        id SERIAL PRIMARY KEY,
        client_name TEXT NOT NULL,
        occasion TEXT NOT NULL,
        rating INTEGER NOT NULL DEFAULT 5,
        comment TEXT NOT NULL,
        product_ordered TEXT NOT NULL,
        verified BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS contact_messages (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        subject TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);

    const [{ value: productCount }] = await db
      .select({ value: count() })
      .from(products);

    if (productCount === 0) {
      await db.insert(products).values(INITIAL_PRODUCTS);
    }

    const [{ value: testimonialCount }] = await db
      .select({ value: count() })
      .from(testimonials);

    if (testimonialCount === 0) {
      await db.insert(testimonials).values(INITIAL_TESTIMONIALS);
    }

    const [{ value: orderCount }] = await db
      .select({ value: count() })
      .from(orders);

    if (orderCount === 0) {
      await db.insert(orders).values([
        {
          orderReference: "BBK-2026-1042",
          customerName: "Amara Nwosu",
          customerPhone: "+234 809 555 0192",
          customerEmail: "amara.n@example.com",
          productId: 1,
          productName: "Rosé Chantilly Lambeth Birthday Cake",
          productCategory: "Birthday cakes",
          cakeSize: "8-inch Classic (20–25 servings)",
          flavorChoice: "Madagascar Vanilla & Raspberry",
          quantity: 1,
          fulfillmentType: "Delivery",
          deliveryAddress: "14 Victoria Island Crescent, Lagos",
          preferredDate: "2026-05-15",
          preferredTime: "2:00 PM",
          specialInstructions: "Write 'Happy 30th Amara' in gold script on top.",
          unitPrice: 110,
          deliveryFee: 15,
          totalPrice: 125,
          status: "Confirmed",
        },
      ]);
    }

    initialized = true;
  } catch (error) {
    console.error("Database seed check error:", error);
  }
}
