"use client";

import React, { useState, useMemo } from "react";
import type { Product, Testimonial, Order } from "@/db/schema";
import {
  Sparkles,
  ShoppingBag,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Clock,
  Check,
  ChevronDown,
  ChevronRight,
  Star,
  Pencil,
  Plus,
  Minus,
  Truck,
  Store,
  Heart,
  Award,
  ShieldCheck,
  Search,
  X,
  Copy,
  ExternalLink,
  Menu,
  Cake,
  Utensils,
  Send,
  PackageCheck,
} from "lucide-react";

function Instagram({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

interface BiobukClientAppProps {
  initialProducts: Product[];
  initialTestimonials: Testimonial[];
  initialOrders: Order[];
}

const PRODUCT_CATEGORIES = [
  "All",
  "Birthday cakes",
  "Wedding cakes",
  "Anniversary cakes",
  "Cupcakes",
  "Doughnuts",
  "Small chops",
  "Pastries",
  "Custom cakes",
] as const;

const GALLERY_ITEMS = [
  {
    id: 1,
    title: "La Vie en Rose Two-Tier Atelier Cake",
    category: "Wedding cakes",
    caption: "Handcrafted sugar roses, 24k gold leaf & raspberry Chantilly",
    imageUrl: "/images/hero-cake.jpg",
    aspect: "tall",
  },
  {
    id: 2,
    title: "Vintage Lambeth Rosé Celebration",
    category: "Birthday cakes",
    caption: "French macarons, strawberry crowns & pearl piping",
    imageUrl: "/images/birthday-cake.jpg",
    aspect: "square",
  },
  {
    id: 3,
    title: "Jardin de Peony Grand Three-Tier",
    category: "Wedding cakes",
    caption: "Cascading sugar peonies on warm ivory Swiss meringue",
    imageUrl: "/images/wedding-cake.jpg",
    aspect: "tall",
  },
  {
    id: 4,
    title: "Amour Heart Ruffle Cake",
    category: "Anniversary cakes",
    caption: "Damascus rose petals & ruby berry compote",
    imageUrl: "/images/anniversary-cake.jpg",
    aspect: "square",
  },
  {
    id: 5,
    title: "Couture Swirl Cupcake Collection",
    category: "Cupcakes",
    caption: "Madagascar vanilla bean & dusty rose buttercream",
    imageUrl: "/images/cupcakes.jpg",
    aspect: "square",
  },
  {
    id: 6,
    title: "Rosewater & Espresso Brioche Doughnuts",
    category: "Doughnuts",
    caption: "Cold-fermented brioche with diplomat cream filling",
    imageUrl: "/images/doughnuts.jpg",
    aspect: "wide",
  },
  {
    id: 7,
    title: "Royal Soirée Small Chops Platter",
    category: "Small chops",
    caption: "Golden samosas, spring rolls & honeyed puff-puff",
    imageUrl: "/images/small-chops.jpg",
    aspect: "square",
  },
  {
    id: 8,
    title: "Laminated French Butter Viennoiserie",
    category: "Pastries",
    caption: "Croissants, pain au chocolat & berry custard danishes",
    imageUrl: "/images/pastries.jpg",
    aspect: "square",
  },
  {
    id: 9,
    title: "Palette-Knife Botanical Custom Tier",
    category: "Custom cakes",
    caption: "Bespoke hand-painted buttercream floral reliefs",
    imageUrl: "/images/custom-cake.jpg",
    aspect: "tall",
  },
];

const SIZE_OPTIONS = [
  {
    label: "Standard / 6-Inch Intimate (10–12 servings)",
    multiplier: 1.0,
    badge: "Base Price",
  },
  {
    label: "Classic / 8-Inch Celebration (20–25 servings)",
    multiplier: 1.35,
    badge: "+35%",
  },
  {
    label: "Grand / 10-Inch Banquet (35–45 servings)",
    multiplier: 1.75,
    badge: "+75%",
  },
  {
    label: "Two-Tier Luxury Edition (60–80 servings)",
    multiplier: 2.4,
    badge: "2.4x",
  },
  {
    label: "Three-Tier Couture Statement (100+ servings)",
    multiplier: 3.2,
    badge: "3.2x",
  },
  {
    label: "Box of 6 / Standard Party Platter",
    multiplier: 1.0,
    badge: "Base Price",
  },
  {
    label: "Box of 12 / Deluxe Double Platter",
    multiplier: 1.85,
    badge: "+85%",
  },
];

const FLAVOR_OPTIONS = [
  "Madagascar Vanilla Bean & Raspberry Compote",
  "Velvet Rosewater & Cream Cheese Mousseline",
  "Belgian 70% Dark Chocolate Truffle Ganache",
  "Salted Caramel Praline & Roasted Hazelnut",
  "Champagne Strawberry & Elderflower Crème",
  "Red Velvet Crème & White Chocolate Curls",
  "Lemon Curd & Wild Blueberry Mascarpone",
  "Chef's Signature Savory / Assorted Selection",
];

const FAQ_ITEMS = [
  {
    question: "How far in advance should I place my BIOBUK cake or pastry order?",
    answer:
      "For signature Birthday Cakes, Anniversary Cakes, Cupcakes, Doughnuts, Small Chops, and Pastries, we recommend ordering 24 to 48 hours in advance. Same-day pickup or delivery is available on select fresh daily boxes ordered before 11:00 AM. For multi-tier Wedding Cakes and complex Custom Sculptural Cakes, please book 1 to 3 weeks ahead.",
  },
  {
    question: "Can I customize the colors, inscription, and flavors of my cake?",
    answer:
      "Absolutely! Every BIOBUK cake is handcrafted to order. In our Online Ordering Studio below, you can choose your preferred sponge and filling profile, select your tier/size, and write your exact cake inscription, color palette requests, or dietary notes in the Special Instructions box.",
  },
  {
    question: "How does the WhatsApp ordering button work?",
    answer:
      "Once you fill in your order details (name, phone, selected treat, size, quantity, pickup or delivery, and preferred date), clicking 'Order via WhatsApp' automatically logs your order reference in our system and opens WhatsApp with a neatly formatted order summary ready to send directly to our Head Concierge (+234 809 246 2850).",
  },
  {
    question: "Do you offer safe delivery for tiered cakes and small chops platters?",
    answer:
      "Yes! BIOBUK operates climate-controlled pâtisserie delivery vans across the city. Tiered cakes are transported in chilled anti-slip cake boxes and assembled on-site when needed so your centerpiece arrives in pristine condition.",
  },
  {
    question: "How can I edit product prices on the menu?",
    answer:
      "Each product card features an interactive 'Edit Price' button (pencil icon) next to the price tag. Click it to type a new price and press Save—the updated price is immediately saved to the database and reflected in the live Online Order Calculator.",
  },
  {
    question: "Do you cater for corporate events, weddings, and dietary requirements?",
    answer:
      "We regularly cater luxury weddings, milestone birthdays, corporate launches, and bridal showers with bespoke dessert tables and gourmet small chops stations. We also offer eggless, nut-free, and reduced-sugar artisanal recipes upon request.",
  },
];

const BUSINESS_CONTACT = {
  phoneDisplay: "+234 (0) 809 246 2850",
  phoneRaw: "+2348092462850",
  whatsappNumber: "2348092462850",
  whatsappDisplay: "+234 809 246 2850",
  email: "orders@biobukbakery.com",
  instagramHandle: "@biobuk.patisserie",
  instagramUrl: "https://instagram.com/biobuk.patisserie",
  location: "24 Blossom Atelier Way, Victoria Island, Lagos",
  hours: "Mon – Sat: 8:00 AM – 8:00 PM | Sun: 10:00 AM – 6:00 PM",
};

export default function BiobukClientApp({
  initialProducts,
  initialTestimonials,
  initialOrders,
}: BiobukClientAppProps) {
  // Products state
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [priceManagerMode, setPriceManagerMode] = useState<boolean>(false);

  // Inline price editing state
  const [editingProductId, setEditingProductId] = useState<number | null>(null);
  const [editingPriceValue, setEditingPriceValue] = useState<string>("");
  const [editingDescriptionValue, setEditingDescriptionValue] =
    useState<string>("");
  const [savingProductId, setSavingProductId] = useState<number | null>(null);

  // Add new product modal state
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [newProductForm, setNewProductForm] = useState({
    name: "",
    category: "Birthday cakes",
    description: "",
    basePrice: "75",
    badge: "New Creation",
    servingsInfo: "Serves 12–25 guests",
    leadTime: "48h Notice",
  });
  const [creatingProduct, setCreatingProduct] = useState(false);

  // Gallery state
  const [galleryFilter, setGalleryFilter] = useState<string>("All");
  const [lightboxItem, setLightboxItem] = useState<
    (typeof GALLERY_ITEMS)[number] | null
  >(null);

  // Order form state
  const defaultProduct = initialProducts[0] || {
    id: 1,
    name: "Rosé Chantilly Lambeth Birthday Cake",
    category: "Birthday cakes",
    basePrice: 85,
  };

  const tomorrowDate = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return d.toISOString().split("T")[0];
  }, []);

  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [selectedProductId, setSelectedProductId] = useState<number>(
    defaultProduct.id
  );
  const [cakeSize, setCakeSize] = useState<string>(SIZE_OPTIONS[0].label);
  const [flavorChoice, setFlavorChoice] = useState<string>(FLAVOR_OPTIONS[0]);
  const [quantity, setQuantity] = useState<number>(1);
  const [fulfillmentType, setFulfillmentType] = useState<"Pickup" | "Delivery">(
    "Pickup"
  );
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [preferredDate, setPreferredDate] = useState<string>(tomorrowDate);
  const [preferredTime, setPreferredTime] = useState<string>("2:00 PM");
  const [specialInstructions, setSpecialInstructions] = useState("");

  // Order submission & confirmation state
  const [submittingOrder, setSubmittingOrder] = useState(false);
  const [orderError, setOrderError] = useState<string | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>(initialOrders);
  const [showOrderTrackerModal, setShowOrderTrackerModal] = useState(false);
  const [lookupReference, setLookupReference] = useState("");
  const [copiedWhatsAppText, setCopiedWhatsAppText] = useState(false);

  // Testimonials & FAQ state
  const [testimonials, setTestimonials] =
    useState<Testimonial[]>(initialTestimonials);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewForm, setReviewForm] = useState({
    clientName: "",
    occasion: "Birthday Celebration",
    rating: 5,
    productOrdered: "Rosé Chantilly Lambeth Birthday Cake",
    comment: "",
  });
  const [submittingReview, setSubmittingReview] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Contact form state
  const [contactForm, setContactForm] = useState({
    name: "",
    phone: "",
    email: "",
    subject: "Bespoke Cake Consultation",
    message: "",
  });
  const [sendingContact, setSendingContact] = useState(false);
  const [contactSuccess, setContactSuccess] = useState(false);
  const [copiedContactField, setCopiedContactField] = useState<string | null>(
    null
  );

  // Mobile Menu & Toast notification
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4000);
  };

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter((item) => {
      const matchesCategory =
        activeCategory === "All" ||
        item.category.toLowerCase() === activeCategory.toLowerCase();
      const matchesSearch =
        !searchQuery.trim() ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [products, activeCategory, searchQuery]);

  // Filtered gallery
  const filteredGallery = useMemo(() => {
    if (galleryFilter === "All") return GALLERY_ITEMS;
    if (galleryFilter === "Wedding & Tiered") {
      return GALLERY_ITEMS.filter(
        (g) =>
          g.category === "Wedding cakes" || g.category === "Custom cakes"
      );
    }
    if (galleryFilter === "Birthday & Romance") {
      return GALLERY_ITEMS.filter(
        (g) =>
          g.category === "Birthday cakes" ||
          g.category === "Anniversary cakes" ||
          g.category === "Cupcakes"
      );
    }
    return GALLERY_ITEMS.filter(
      (g) =>
        g.category === "Doughnuts" ||
        g.category === "Small chops" ||
        g.category === "Pastries"
    );
  }, [galleryFilter]);

  // Currently selected product in Order Studio
  const selectedProduct = useMemo(() => {
    return (
      products.find((p) => p.id === Number(selectedProductId)) ||
      products[0] ||
      defaultProduct
    );
  }, [products, selectedProductId, defaultProduct]);

  // Live price calculation
  const pricingSummary = useMemo(() => {
    const base = selectedProduct?.basePrice || 65;
    const sizeObj =
      SIZE_OPTIONS.find((s) => s.label === cakeSize) || SIZE_OPTIONS[0];
    const unitPrice = Math.round(base * sizeObj.multiplier);
    const subtotal = unitPrice * Math.max(1, quantity);
    const deliveryFee = fulfillmentType === "Delivery" ? 15 : 0;
    const total = subtotal + deliveryFee;
    return {
      base,
      multiplier: sizeObj.multiplier,
      unitPrice,
      subtotal,
      deliveryFee,
      total,
    };
  }, [selectedProduct, cakeSize, quantity, fulfillmentType]);

  // Start editing a product's price & description
  const startEditingProduct = (product: Product) => {
    setEditingProductId(product.id);
    setEditingPriceValue(String(product.basePrice));
    setEditingDescriptionValue(product.description);
  };

  // Save edited product price & description to PostgreSQL
  const handleSaveProductEdit = async (productId: number) => {
    const parsedPrice = Math.round(Number(editingPriceValue));
    if (Number.isNaN(parsedPrice) || parsedPrice < 1) {
      showToast("Please enter a valid price ($1 or higher).");
      return;
    }

    setSavingProductId(productId);
    try {
      const response = await fetch(`/api/products/${productId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          basePrice: parsedPrice,
          description: editingDescriptionValue.trim(),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to update price.");
      }

      setProducts((prev) =>
        prev.map((item) => (item.id === productId ? data.product : item))
      );
      setEditingProductId(null);
      showToast(
        `Updated "${data.product.name}" price to $${data.product.basePrice}!`
      );
    } catch (err) {
      showToast(
        err instanceof Error ? err.message : "Could not update product price."
      );
    } finally {
      setSavingProductId(null);
    }
  };

  // Create a brand new bakery item
  const handleCreateNewProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductForm.name.trim() || !newProductForm.description.trim()) {
      showToast("Please fill in the product name and description.");
      return;
    }

    setCreatingProduct(true);
    try {
      const categoryImageMap: Record<string, string> = {
        "Birthday cakes": "/images/birthday-cake.jpg",
        "Wedding cakes": "/images/wedding-cake.jpg",
        "Anniversary cakes": "/images/anniversary-cake.jpg",
        Cupcakes: "/images/cupcakes.jpg",
        Doughnuts: "/images/doughnuts.jpg",
        "Small chops": "/images/small-chops.jpg",
        Pastries: "/images/pastries.jpg",
        "Custom cakes": "/images/custom-cake.jpg",
      };

      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newProductForm,
          basePrice: Number(newProductForm.basePrice) || 65,
          imageUrl:
            categoryImageMap[newProductForm.category] ||
            "/images/custom-cake.jpg",
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to add product");

      setProducts((prev) => [...prev, data.product]);
      setShowAddProductModal(false);
      setNewProductForm({
        name: "",
        category: "Birthday cakes",
        description: "",
        basePrice: "75",
        badge: "New Creation",
        servingsInfo: "Serves 12–25 guests",
        leadTime: "48h Notice",
      });
      showToast(`Added "${data.product.name}" to the BIOBUK menu!`);
    } catch (err) {
      showToast(
        err instanceof Error ? err.message : "Could not create product."
      );
    } finally {
      setCreatingProduct(false);
    }
  };

  // Select a product from card and scroll to order studio
  const handleSelectProductForOrder = (product: Product) => {
    setSelectedProductId(product.id);
    if (
      product.category === "Cupcakes" ||
      product.category === "Doughnuts" ||
      product.category === "Small chops" ||
      product.category === "Pastries"
    ) {
      setCakeSize(SIZE_OPTIONS[5].label); // Box of 6 / Standard Platter
    } else if (product.category === "Wedding cakes") {
      setCakeSize(SIZE_OPTIONS[3].label); // Two-Tier or Standard
    } else {
      setCakeSize(SIZE_OPTIONS[0].label);
    }
    showToast(`Selected "${product.name}" in the Order Studio.`);
    const el = document.getElementById("order-studio");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  // Build formatted WhatsApp order text
  const buildWhatsAppMessage = (orderRef?: string) => {
    const lines = [
      `✨ *NEW ORDER — BIOBUK HAUTE PÂTISSERIE* ✨`,
      orderRef ? `*Order Reference:* ${orderRef}` : "",
      `----------------------------------`,
      `👤 *Customer Name:* ${customerName.trim() || "Valued Guest"}`,
      `📞 *Phone Number:* ${customerPhone.trim() || "Not specified"}`,
      customerEmail.trim() ? `✉️ *Email:* ${customerEmail.trim()}` : "",
      `----------------------------------`,
      `🎂 *Selected Treat:* ${selectedProduct.name}`,
      `🏷️ *Category:* ${selectedProduct.category}`,
      `📏 *Size / Option:* ${cakeSize}`,
      `🍓 *Flavor Profile:* ${flavorChoice}`,
      `🔢 *Quantity:* ${quantity}`,
      `🚚 *Fulfillment:* ${fulfillmentType}`,
      fulfillmentType === "Delivery" && deliveryAddress.trim()
        ? `📍 *Delivery Address:* ${deliveryAddress.trim()}`
        : "",
      `📅 *Preferred Date:* ${preferredDate} (${preferredTime})`,
      specialInstructions.trim()
        ? `📝 *Special Instructions:* ${specialInstructions.trim()}`
        : `📝 *Special Instructions:* Standard BIOBUK presentation`,
      `----------------------------------`,
      `💳 *Estimated Total:* $${pricingSummary.total} (${
        fulfillmentType === "Delivery"
          ? `includes $${pricingSummary.deliveryFee} delivery`
          : "Atelier Pickup"
      })`,
      `----------------------------------`,
      `Please confirm availability and payment details. Thank you! 🌸`,
    ].filter(Boolean);

    return lines.join("\n");
  };

  // Submit order to PostgreSQL
  const submitOrderToDatabase = async (): Promise<Order | null> => {
    setOrderError(null);

    if (!customerName.trim() || !customerPhone.trim()) {
      setOrderError(
        "Please enter your full name and phone number so our pâtissiers can reach you."
      );
      return null;
    }

    if (fulfillmentType === "Delivery" && !deliveryAddress.trim()) {
      setOrderError(
        "Please provide your delivery street address for our chilled courier."
      );
      return null;
    }

    setSubmittingOrder(true);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: customerName.trim(),
          customerPhone: customerPhone.trim(),
          customerEmail: customerEmail.trim(),
          productId: selectedProduct.id,
          productName: selectedProduct.name,
          productCategory: selectedProduct.category,
          cakeSize,
          flavorChoice,
          quantity,
          fulfillmentType,
          deliveryAddress:
            fulfillmentType === "Delivery" ? deliveryAddress.trim() : null,
          preferredDate,
          preferredTime,
          specialInstructions: specialInstructions.trim(),
          unitPrice: pricingSummary.unitPrice,
          deliveryFee: pricingSummary.deliveryFee,
          totalPrice: pricingSummary.total,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Could not process order.");
      }

      setConfirmedOrder(data.order);
      setRecentOrders((prev) => [data.order, ...prev]);
      showToast(
        `Order ${data.order.orderReference} confirmed! View your summary below.`
      );
      return data.order;
    } catch (err) {
      setOrderError(
        err instanceof Error
          ? err.message
          : "Something went wrong placing your order."
      );
      return null;
    } finally {
      setSubmittingOrder(false);
    }
  };

  // Handler for Website Order button
  const handleWebsiteOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitOrderToDatabase();
  };

  // Handler for Functional WhatsApp Ordering button
  const handleWhatsAppOrder = async () => {
    if (!customerName.trim() || !customerPhone.trim()) {
      setOrderError(
        "Please enter your Name and Phone Number first so we can include them in your WhatsApp order."
      );
      const nameInput = document.getElementById("order-customer-name");
      nameInput?.focus();
      return;
    }

    if (fulfillmentType === "Delivery" && !deliveryAddress.trim()) {
      setOrderError(
        "Please enter your delivery address before dispatching to WhatsApp."
      );
      return;
    }

    // Save to database first so customer gets an official reference number
    const savedOrder = await submitOrderToDatabase();
    const messageText = buildWhatsAppMessage(savedOrder?.orderReference);
    const encoded = encodeURIComponent(messageText);
    const whatsappUrl = `https://wa.me/${BUSINESS_CONTACT.whatsappNumber}?text=${encoded}`;

    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
  };

  // Copy WhatsApp message text to clipboard
  const handleCopyWhatsAppMessage = async (orderRef?: string) => {
    const msg = buildWhatsAppMessage(orderRef);
    try {
      await navigator.clipboard.writeText(msg);
      setCopiedWhatsAppText(true);
      showToast("Formatted WhatsApp order copied to clipboard!");
      setTimeout(() => setCopiedWhatsAppText(false), 3000);
    } catch {
      showToast("Could not copy automatically.");
    }
  };

  // Copy contact info helper
  const handleCopyContact = async (label: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedContactField(label);
      showToast(`${label} copied to clipboard!`);
      setTimeout(() => setCopiedContactField(null), 2500);
    } catch {
      showToast(value);
    }
  };

  // Submit customer review
  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewForm.clientName.trim() || !reviewForm.comment.trim()) {
      showToast("Please enter your name and review message.");
      return;
    }
    setSubmittingReview(true);
    try {
      const res = await fetch("/api/testimonials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reviewForm),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not post review.");
      setTestimonials((prev) => [data.testimonial, ...prev]);
      setShowReviewModal(false);
      setReviewForm({
        clientName: "",
        occasion: "Birthday Celebration",
        rating: 5,
        productOrdered: products[0]?.name || "Signature BIOBUK Cake",
        comment: "",
      });
      showToast("Thank you! Your celebration review is now live.");
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Failed to save review.");
    } finally {
      setSubmittingReview(false);
    }
  };

  // Submit contact inquiry
  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !contactForm.name.trim() ||
      !contactForm.phone.trim() ||
      !contactForm.message.trim()
    ) {
      showToast("Please complete your name, phone number, and message.");
      return;
    }
    setSendingContact(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(contactForm),
      });
      if (!res.ok) throw new Error("Failed to send message");
      setContactSuccess(true);
      setContactForm({
        name: "",
        phone: "",
        email: "",
        subject: "Bespoke Cake Consultation",
        message: "",
      });
      showToast(
        "Your message has been received by the BIOBUK Concierge Desk!"
      );
    } catch {
      showToast("Could not send inquiry right now. Please message us on WhatsApp.");
    } finally {
      setSendingContact(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFBF7] text-[#2C1A14]">
      {/* Top Announcement Ribbon */}
      <div className="bg-[#2C1A14] text-[#FCEEE9] text-xs sm:text-sm py-2.5 px-4 border-b border-[#8C5843]/30">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#D87A88] shrink-0" />
            <span className="tracking-wide">
              <strong className="font-semibold text-white">BIOBUK ATELIER:</strong>{" "}
              Freshly baked artisanal cakes, French pastries &amp; gourmet small
              chops crafted daily.
            </span>
          </div>
          <div className="hidden md:flex items-center gap-5 text-xs text-[#EBD8D0]">
            <a
              href={`tel:${BUSINESS_CONTACT.phoneRaw}`}
              className="hover:text-white transition-colors flex items-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-[#D87A88]" />
              {BUSINESS_CONTACT.phoneDisplay}
            </a>
            <span className="text-[#8C5843]">•</span>
            <button
              type="button"
              onClick={() => setShowOrderTrackerModal(true)}
              className="hover:text-white transition-colors flex items-center gap-1.5 underline underline-offset-4 decoration-[#D87A88]"
            >
              <PackageCheck className="w-3.5 h-3.5 text-[#D87A88]" />
              Track Order ({recentOrders.length})
            </button>
          </div>
        </div>
      </div>

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md bg-[#2C1A14] text-[#FFFBF7] px-5 py-3.5 rounded-2xl shadow-2xl border border-[#D87A88]/40 flex items-center gap-3 animate-bounce">
          <div className="w-7 h-7 rounded-full bg-[#D87A88]/20 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-[#D87A88]" />
          </div>
          <p className="text-sm font-medium">{toastMessage}</p>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            className="ml-auto text-[#EBD8D0] hover:text-white"
            aria-label="Close notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sticky Glassmorphic Navigation Header */}
      <header className="sticky top-0 z-40 h-20 bg-[#FFFBF7]/90 backdrop-blur-md border-b border-[#EBD8D0] transition-all">
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          {/* BIOBUK Elegant Text Logo & Crest */}
          <a
            href="#top"
            className="group flex items-center gap-3.5 focus:outline-none"
          >
            <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#FCEEE9] to-[#F7D6DC] border border-[#D87A88]/40 flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
              <Cake className="w-5 h-5 text-[#2C1A14]" />
            </div>
            <div className="flex flex-col">
              <span className="font-editorial text-2xl sm:text-3xl font-bold tracking-[0.22em] text-[#2C1A14] leading-none">
                BIOBUK
              </span>
              <span className="text-[10px] uppercase tracking-[0.25em] text-[#8C5843] font-semibold mt-1">
                Haute Pâtisserie &amp; Bakery
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav
            aria-label="Main Navigation"
            className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#6E5249]"
          >
            <a
              href="#about"
              className="hover:text-[#2C1A14] transition-colors py-1"
            >
              About BIOBUK
            </a>
            <a
              href="#products"
              className="hover:text-[#2C1A14] transition-colors py-1"
            >
              Our Products
            </a>
            <a
              href="#gallery"
              className="hover:text-[#2C1A14] transition-colors py-1"
            >
              Cake Gallery
            </a>
            <a
              href="#order-studio"
              className="hover:text-[#2C1A14] transition-colors py-1"
            >
              Online Ordering
            </a>
            <a
              href="#testimonials"
              className="hover:text-[#2C1A14] transition-colors py-1"
            >
              Reviews &amp; FAQ
            </a>
            <a
              href="#contact"
              className="hover:text-[#2C1A14] transition-colors py-1"
            >
              Contact
            </a>
          </nav>

          {/* Header CTA Buttons */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href={`https://wa.me/${BUSINESS_CONTACT.whatsappNumber}?text=${encodeURIComponent(
                "Hello BIOBUK Bakery! I would love to inquire about ordering a cake/pastry."
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider border border-[#EBD8D0] bg-white text-[#2C1A14] hover:border-[#D87A88] hover:bg-[#FCEEE9]/50 transition-all"
            >
              <MessageCircle className="w-4 h-4 text-[#2E6F40]" />
              <span className="hidden xl:inline">WhatsApp</span>
            </a>

            <a
              href="#order-studio"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-xs sm:text-sm font-semibold uppercase tracking-wider bg-[#2C1A14] text-[#FFFBF7] hover:bg-[#8C5843] shadow-md hover:shadow-lg transition-all"
            >
              <ShoppingBag className="w-4 h-4 text-[#D87A88]" />
              ORDER NOW
            </a>
          </div>

          {/* Mobile Hamburger Trigger */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2.5 rounded-xl border border-[#EBD8D0] bg-white text-[#2C1A14] hover:bg-[#FCEEE9]"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Mobile Slide-Down Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FFFBF7] border-b border-[#EBD8D0] px-6 py-6 shadow-xl space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm font-medium text-[#2C1A14]">
              <a
                href="#about"
                onClick={() => setMobileMenuOpen(false)}
                className="p-3 rounded-xl bg-[#FCEEE9]/60 hover:bg-[#FCEEE9]"
              >
                About BIOBUK
              </a>
              <a
                href="#products"
                onClick={() => setMobileMenuOpen(false)}
                className="p-3 rounded-xl bg-[#FCEEE9]/60 hover:bg-[#FCEEE9]"
              >
                Our Products
              </a>
              <a
                href="#gallery"
                onClick={() => setMobileMenuOpen(false)}
                className="p-3 rounded-xl bg-[#FCEEE9]/60 hover:bg-[#FCEEE9]"
              >
                Cake Gallery
              </a>
              <a
                href="#order-studio"
                onClick={() => setMobileMenuOpen(false)}
                className="p-3 rounded-xl bg-[#FCEEE9]/60 hover:bg-[#FCEEE9]"
              >
                Online Ordering
              </a>
              <a
                href="#testimonials"
                onClick={() => setMobileMenuOpen(false)}
                className="p-3 rounded-xl bg-[#FCEEE9]/60 hover:bg-[#FCEEE9]"
              >
                Reviews &amp; FAQ
              </a>
              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="p-3 rounded-xl bg-[#FCEEE9]/60 hover:bg-[#FCEEE9]"
              >
                Contact Salon
              </a>
            </div>
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <a
                href="#order-studio"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-3.5 rounded-full bg-[#2C1A14] text-[#FFFBF7] text-center text-sm font-semibold uppercase tracking-wider shadow-md"
              >
                ORDER NOW
              </a>
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setShowOrderTrackerModal(true);
                }}
                className="w-full py-3 rounded-full border border-[#8C5843] text-[#2C1A14] text-center text-xs font-semibold uppercase tracking-wider"
              >
                Track Existing Order
              </button>
            </div>
          </div>
        )}
      </header>

      {/* =========================================================
          2. HOMEPAGE HERO SECTION
      ========================================================= */}
      <section
        id="top"
        className="relative overflow-hidden pt-10 pb-20 lg:pt-16 lg:pb-28 hero-radial-aura border-b border-[#EBD8D0]/80"
      >
        {/* Decorative Subtle Blobs */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-24 -left-24 w-96 h-96 rounded-full bg-[#FCEEE9] blur-3xl opacity-80"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute bottom-0 right-0 w-[30rem] h-[30rem] rounded-full bg-[#F7D6DC]/50 blur-3xl opacity-70"
        />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
            {/* Left Column (7 cols): Brand Identity, Headline, Welcome Message, CTAs */}
            <div className="lg:col-span-7 space-y-7">
              <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-[#FCEEE9] border border-[#D87A88]/40">
                <span className="w-2 h-2 rounded-full bg-[#D87A88] animate-ping" />
                <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8C5843]">
                  EST. ARTISANAL CAKE &amp; PASTRY ATELIER
                </span>
              </div>

              <div className="space-y-4">
                <p className="font-editorial italic text-xl sm:text-2xl text-[#8C5843]">
                  Welcome to BIOBUK Haute Pâtisserie
                </p>
                <h1 className="font-editorial text-4xl sm:text-6xl lg:text-[4.15rem] font-bold text-[#2C1A14] leading-[1.08] tracking-tight">
                  Baking Happiness,{" "}
                  <span className="italic font-normal text-[#D87A88] underline decoration-[#EBD8D0] decoration-2 underline-offset-8">
                    One Treat
                  </span>{" "}
                  at a Time.
                </h1>
              </div>

              <p className="text-base sm:text-lg text-[#6E5249] leading-relaxed max-w-2xl">
                Welcome to <strong className="text-[#2C1A14]">BIOBUK</strong>,
                where silky Madagascar vanilla bean, cultured French butter, and
                delicate hand-piped sugar artistry come together. From grand
                multi-tier wedding masterpieces and milestone birthday cakes to
                warm brioche doughnuts and gourmet small chops, we bake every
                celebration into an unforgettable memory.
              </p>

              {/* Prominent CTA Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <a
                  href="#order-studio"
                  className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-[#2C1A14] text-[#FFFBF7] hover:bg-[#8C5843] text-sm sm:text-base font-semibold tracking-wider uppercase shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all"
                >
                  <ShoppingBag className="w-5 h-5 text-[#D87A88]" />
                  ORDER NOW
                  <ChevronRight className="w-4 h-4" />
                </a>

                <a
                  href="#products"
                  className="inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-full bg-white text-[#2C1A14] border-2 border-[#EBD8D0] hover:border-[#D87A88] hover:bg-[#FCEEE9]/40 text-sm sm:text-base font-semibold tracking-wide transition-all"
                >
                  Explore Our Menu
                </a>
              </div>

              {/* Trust & Sensory Metrics Bar */}
              <div className="pt-6 border-t border-[#EBD8D0] grid grid-cols-3 gap-4 sm:gap-8 max-w-xl">
                <div>
                  <p className="font-editorial text-2xl sm:text-3xl font-bold text-[#2C1A14]">
                    100%
                  </p>
                  <p className="text-xs sm:text-sm text-[#6E5249] mt-0.5">
                    Freshly Baked Daily
                  </p>
                </div>
                <div>
                  <p className="font-editorial text-2xl sm:text-3xl font-bold text-[#2C1A14]">
                    4.9★
                  </p>
                  <p className="text-xs sm:text-sm text-[#6E5249] mt-0.5">
                    2,400+ Celebration Orders
                  </p>
                </div>
                <div>
                  <p className="font-editorial text-2xl sm:text-3xl font-bold text-[#2C1A14]">
                    8+
                  </p>
                  <p className="text-xs sm:text-sm text-[#6E5249] mt-0.5">
                    Signature Collections
                  </p>
                </div>
              </div>
            </div>

            {/* Right Column (5 cols): Hero Professionally Decorated Cake Showcase */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Soft Blush Arch Backdrop */}
                <div className="absolute -inset-3 rounded-t-[14rem] rounded-b-[2.5rem] bg-gradient-to-b from-[#FCEEE9] via-[#F7D6DC]/60 to-[#EBD8D0]/40 -rotate-2" />

                {/* Main Arched Hero Image Card */}
                <div className="relative rounded-t-[13rem] rounded-b-[2rem] overflow-hidden bg-white p-3 border border-[#EBD8D0] patisserie-shadow-lg">
                  <div className="relative rounded-t-[12.2rem] rounded-b-[1.5rem] overflow-hidden aspect-[4/5]">
                    <img
                      src="/images/hero-cake.jpg"
                      alt="BIOBUK Signature Tiered Blush Pink and Cream Celebration Cake"
                      className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#2C1A14]/60 via-transparent to-transparent" />

                    {/* Caption inside hero image bottom */}
                    <div className="absolute bottom-4 left-4 right-4 bg-[#FFFBF7]/95 backdrop-blur-md p-4 rounded-2xl border border-[#EBD8D0] flex items-center justify-between gap-3">
                      <div>
                        <span className="text-[10px] uppercase tracking-[0.2em] text-[#8C5843] font-bold block">
                          Signature Centerpiece
                        </span>
                        <p className="font-editorial text-lg font-bold text-[#2C1A14] leading-snug">
                          La Vie en Rose Two-Tier Cake
                        </p>
                      </div>
                      <a
                        href="#order-studio"
                        className="px-3.5 py-2 rounded-full bg-[#D87A88] text-white text-xs font-semibold hover:bg-[#2C1A14] transition-colors shrink-0"
                      >
                        Order This
                      </a>
                    </div>
                  </div>
                </div>

                {/* Floating Artisanal Badge Top-Left */}
                <div className="hidden sm:flex absolute -left-6 top-14 bg-white/95 backdrop-blur-md px-4 py-3 rounded-2xl border border-[#EBD8D0] patisserie-shadow items-center gap-3 animate-float-slow">
                  <div className="w-10 h-10 rounded-full bg-[#FCEEE9] flex items-center justify-center text-[#D87A88]">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#2C1A14]">
                      Handcrafted Sugar Florals
                    </p>
                    <p className="text-[11px] text-[#6E5249]">
                      Madagascar Vanilla &amp; Berry
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          3. ABOUT BIOBUK SECTION
      ========================================================= */}
      <section
        id="about"
        className="py-20 lg:py-28 bg-[#FFFBF7] border-b border-[#EBD8D0]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
            {/* Left Image Composition (5 cols) */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-3xl overflow-hidden border border-[#EBD8D0] bg-white p-3 patisserie-shadow">
                <img
                  src="/images/atelier-about.jpg"
                  alt="BIOBUK Pastry Chef decorating a luxury blush pink tiered cake"
                  className="w-full h-[420px] sm:h-[480px] object-cover rounded-2xl"
                />
                <div className="mt-3 p-4 rounded-2xl bg-[#FCEEE9]/70 border border-[#EBD8D0] flex items-center justify-between">
                  <div>
                    <p className="font-editorial text-lg font-bold text-[#2C1A14]">
                      The BIOBUK Pâtisserie Promise
                    </p>
                    <p className="text-xs text-[#6E5249]">
                      Zero artificial preservatives • Baked fresh for your date
                    </p>
                  </div>
                  <Heart className="w-6 h-6 text-[#D87A88] fill-[#D87A88]/20 shrink-0" />
                </div>
              </div>
            </div>

            {/* Right Story & Pillars (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FCEEE9] text-[#8C5843] text-xs font-semibold uppercase tracking-[0.18em]">
                <Sparkles className="w-3.5 h-3.5 text-[#D87A88]" />
                Our Story &amp; Craftsmanship
              </div>

              <h2 className="font-editorial text-3xl sm:text-5xl font-bold text-[#2C1A14] leading-[1.12]">
                Dedicated to Making Delicious, Beautiful Cakes &amp; Pastries
                for Every Celebration.
              </h2>

              <p className="text-base sm:text-lg text-[#6E5249] leading-relaxed">
                At <strong className="text-[#2C1A14]">BIOBUK</strong>, we
                believe every milestone—whether an intimate family birthday, a
                grand wedding reception, a romantic anniversary, or a joyful
                Friday afternoon—deserves a centerpiece that looks like fine art
                and tastes like pure bliss.
              </p>

              <p className="text-base text-[#6E5249] leading-relaxed">
                Founded out of a passion for haute confectionery and warm
                hospitality, our bakery blends classic French pâtisserie
                techniques with beloved celebration favorites. From delicate
                buttercream cakes and flaky laminated pastries to golden,
                crowd-pleasing small chops platters, every item leaves our ovens
                warm, fragrant, and meticulously finished.
              </p>

              {/* Three Pillars Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3">
                <div className="p-5 rounded-2xl bg-white border border-[#EBD8D0] patisserie-shadow">
                  <div className="w-10 h-10 rounded-xl bg-[#FCEEE9] flex items-center justify-center text-[#8C5843] mb-3">
                    <Award className="w-5 h-5 text-[#D87A88]" />
                  </div>
                  <h3 className="font-editorial text-xl font-bold text-[#2C1A14]">
                    Finest Ingredients
                  </h3>
                  <p className="text-xs sm:text-sm text-[#6E5249] mt-1.5 leading-relaxed">
                    Cultured dairy butter, farm-fresh eggs, Belgian couverture
                    chocolate, and real fruit compotes.
                  </p>
                </div>

                <div className="p-5 rounded-2xl bg-white border border-[#EBD8D0] patisserie-shadow">
                  <div className="w-10 h-10 rounded-xl bg-[#FCEEE9] flex items-center justify-center text-[#8C5843] mb-3">
                    <Cake className="w-5 h-5 text-[#D87A88]" />
                  </div>
                  <h3 className="font-editorial text-xl font-bold text-[#2C1A14]">
                    Bespoke Artistry
                  </h3>
                  <p className="text-xs sm:text-sm text-[#6E5249] mt-1.5 leading-relaxed">
                    Hand-piped Lambeth scrolls, sugar peonies, and palette-knife
                    floral reliefs tailored to your theme.
                  </p>
                </div>

                <div className="p-5 rounded-2xl bg-white border border-[#EBD8D0] patisserie-shadow">
                  <div className="w-10 h-10 rounded-xl bg-[#FCEEE9] flex items-center justify-center text-[#8C5843] mb-3">
                    <ShieldCheck className="w-5 h-5 text-[#D87A88]" />
                  </div>
                  <h3 className="font-editorial text-xl font-bold text-[#2C1A14]">
                    Punctual Delivery
                  </h3>
                  <p className="text-xs sm:text-sm text-[#6E5249] mt-1.5 leading-relaxed">
                    Carefully packaged for salon pickup or delivered chilled
                    straight to your celebration venue.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          4. OUR PRODUCTS SECTION (8 CATEGORIES + EDITABLE PRICES)
      ========================================================= */}
      <section
        id="products"
        className="py-20 lg:py-28 bg-gradient-to-b from-[#FCEEE9]/40 via-[#FFFBF7] to-[#FFFBF7] border-b border-[#EBD8D0]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
            <div className="max-w-2xl space-y-3">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FCEEE9] text-[#8C5843] text-xs font-semibold uppercase tracking-[0.18em]">
                <Utensils className="w-3.5 h-3.5 text-[#D87A88]" />
                Curated Pâtisserie Menu
              </div>
              <h2 className="font-editorial text-3xl sm:text-5xl font-bold text-[#2C1A14]">
                Our Signature Products
              </h2>
              <p className="text-base text-[#6E5249]">
                Explore our handcrafted collections across all 8 bakery
                specialties. Click any price tag or enable{" "}
                <strong className="text-[#2C1A14]">Price Manager Mode</strong>{" "}
                to customize prices live.
              </p>
            </div>

            {/* Search & Price Manager Controls */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative">
                <Search className="w-4 h-4 text-[#8C5843] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search cakes, small chops..."
                  className="pl-10 pr-4 py-2.5 rounded-full bg-white border border-[#EBD8D0] text-sm text-[#2C1A14] placeholder:text-[#6E5249]/60 focus:outline-none focus:border-[#D87A88] w-56 sm:w-64"
                />
              </div>

              <button
                type="button"
                onClick={() => setPriceManagerMode(!priceManagerMode)}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider border transition-all ${
                  priceManagerMode
                    ? "bg-[#D87A88] text-white border-[#D87A88] shadow-sm"
                    : "bg-white text-[#2C1A14] border-[#EBD8D0] hover:border-[#D87A88]"
                }`}
              >
                <Pencil className="w-3.5 h-3.5" />
                {priceManagerMode ? "Done Editing Prices" : "Edit Prices"}
              </button>

              <button
                type="button"
                onClick={() => setShowAddProductModal(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider bg-[#FCEEE9] text-[#2C1A14] border border-[#D87A88]/40 hover:bg-[#D87A88] hover:text-white transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Product
              </button>
            </div>
          </div>

          {/* Category Filter Pills (All 8 Required Categories) */}
          <div className="flex items-center gap-2.5 overflow-x-auto pb-4 mb-8 no-scrollbar">
            {PRODUCT_CATEGORIES.map((category) => {
              const active = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  onClick={() => setActiveCategory(category)}
                  className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                    active
                      ? "bg-[#2C1A14] text-[#FFFBF7] shadow-md"
                      : "bg-white text-[#6E5249] border border-[#EBD8D0] hover:border-[#D87A88] hover:text-[#2C1A14]"
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>

          {/* Product Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-7">
            {filteredProducts.map((product) => {
              const isEditing = editingProductId === product.id;
              const isSaving = savingProductId === product.id;

              return (
                <div
                  key={product.id}
                  className="group bg-white rounded-3xl border border-[#EBD8D0] overflow-hidden patisserie-shadow hover:patisserie-shadow-lg hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
                >
                  <div>
                    {/* Product Image Header */}
                    <div className="relative h-60 overflow-hidden bg-[#FCEEE9]">
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                        <span className="px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-[#FFFBF7]/95 text-[#2C1A14] backdrop-blur-sm border border-[#EBD8D0]">
                          {product.category}
                        </span>
                        {product.badge && (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#D87A88] text-white shadow-sm">
                            {product.badge}
                          </span>
                        )}
                      </div>

                      {/* Editable Price Badge Overlay */}
                      <div className="absolute bottom-3 right-3">
                        {!isEditing ? (
                          <button
                            type="button"
                            onClick={() => startEditingProduct(product)}
                            title="Click to edit price"
                            className="group/price inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#2C1A14]/95 text-[#FFFBF7] hover:bg-[#D87A88] transition-colors shadow-lg border border-white/15"
                          >
                            <span className="text-[11px] text-[#FCEEE9] uppercase tracking-wider">
                              From
                            </span>
                            <span className="font-price text-base font-bold">
                              ${product.basePrice}
                            </span>
                            <Pencil className="w-3 h-3 text-[#D87A88] group-hover/price:text-white ml-0.5" />
                          </button>
                        ) : null}
                      </div>
                    </div>

                    {/* Card Body */}
                    <div className="p-6 space-y-3">
                      <div className="flex items-center justify-between text-xs text-[#8C5843] font-medium">
                        <span className="flex items-center gap-1">
                          <Utensils className="w-3.5 h-3.5 text-[#D87A88]" />
                          {product.servingsInfo}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-[#D87A88]" />
                          {product.leadTime}
                        </span>
                      </div>

                      <h3 className="font-editorial text-2xl font-bold text-[#2C1A14] leading-snug">
                        {product.name}
                      </h3>

                      {/* Inline Price & Description Editor when active or when Price Manager Mode is on */}
                      {isEditing || priceManagerMode ? (
                        <div className="p-3.5 rounded-2xl bg-[#FCEEE9]/70 border border-[#D87A88] space-y-3">
                          <div>
                            <label className="block text-[11px] font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                              Editable Price (USD $)
                            </label>
                            <div className="flex items-center gap-2">
                              <input
                                type="number"
                                min={1}
                                value={
                                  isEditing
                                    ? editingPriceValue
                                    : product.basePrice
                                }
                                onFocus={() => {
                                  if (!isEditing) startEditingProduct(product);
                                }}
                                onChange={(e) => {
                                  if (!isEditing) startEditingProduct(product);
                                  setEditingPriceValue(e.target.value);
                                }}
                                className="w-full px-3 py-1.5 rounded-xl bg-white border border-[#EBD8D0] font-price text-sm font-bold text-[#2C1A14] focus:outline-none focus:border-[#2C1A14]"
                              />
                              <button
                                type="button"
                                disabled={isSaving}
                                onClick={() =>
                                  handleSaveProductEdit(product.id)
                                }
                                className="px-3.5 py-1.5 rounded-xl bg-[#2E6F40] text-white text-xs font-semibold hover:bg-[#2C1A14] transition-colors shrink-0"
                              >
                                {isSaving ? "Saving..." : "Save"}
                              </button>
                              {isEditing && (
                                <button
                                  type="button"
                                  onClick={() => setEditingProductId(null)}
                                  className="p-1.5 rounded-xl bg-white text-[#6E5249] hover:text-[#2C1A14]"
                                  title="Cancel"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </div>

                          {isEditing && (
                            <div>
                              <label className="block text-[11px] font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                                Description
                              </label>
                              <textarea
                                rows={2}
                                value={editingDescriptionValue}
                                onChange={(e) =>
                                  setEditingDescriptionValue(e.target.value)
                                }
                                className="w-full px-3 py-1.5 rounded-xl bg-white border border-[#EBD8D0] text-xs text-[#2C1A14] focus:outline-none"
                              />
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="text-sm text-[#6E5249] leading-relaxed line-clamp-3">
                          {product.description}
                        </p>
                      )}

                      <div className="pt-1">
                        <p className="text-[11px] text-[#8C5843] font-medium">
                          <strong className="text-[#2C1A14]">Flavors:</strong>{" "}
                          {product.flavors}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Card Footer Action */}
                  <div className="px-6 pb-6 pt-2 flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => handleSelectProductForOrder(product)}
                      className="flex-1 py-3 px-4 rounded-full bg-[#2C1A14] text-[#FFFBF7] hover:bg-[#D87A88] text-xs font-semibold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 shadow-sm"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      Order This Treat
                    </button>
                    <button
                      type="button"
                      onClick={() => startEditingProduct(product)}
                      title="Edit Price"
                      className="p-3 rounded-full border border-[#EBD8D0] bg-[#FFFBF7] text-[#6E5249] hover:text-[#2C1A14] hover:border-[#D87A88] transition-colors"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* =========================================================
          5. GALLERY SECTION (CAKE DESIGNS & BAKERY SHOWCASE)
      ========================================================= */}
      <section
        id="gallery"
        className="py-20 lg:py-28 bg-[#FFFBF7] border-b border-[#EBD8D0]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div className="space-y-3 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FCEEE9] text-[#8C5843] text-xs font-semibold uppercase tracking-[0.18em]">
                <Sparkles className="w-3.5 h-3.5 text-[#D87A88]" />
                Lookbook &amp; Exhibition
              </div>
              <h2 className="font-editorial text-3xl sm:text-5xl font-bold text-[#2C1A14]">
                The BIOBUK Cake &amp; Pastry Gallery
              </h2>
              <p className="text-base text-[#6E5249]">
                Every creation is styled with couture precision. Click any
                photograph to inspect the details or request a similar design
                for your upcoming event.
              </p>
            </div>

            {/* Gallery Filter Buttons */}
            <div className="flex flex-wrap gap-2">
              {[
                "All",
                "Wedding & Tiered",
                "Birthday & Romance",
                "Pastries & Small Chops",
              ].map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setGalleryFilter(tab)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all ${
                    galleryFilter === tab
                      ? "bg-[#D87A88] text-white shadow-sm"
                      : "bg-[#FCEEE9]/60 text-[#2C1A14] hover:bg-[#FCEEE9]"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-7">
            {filteredGallery.map((item) => (
              <div
                key={item.id}
                onClick={() => setLightboxItem(item)}
                className="group cursor-pointer relative rounded-3xl overflow-hidden bg-white border border-[#EBD8D0] p-2.5 patisserie-shadow hover:patisserie-shadow-lg transition-all"
              >
                <div className="relative h-80 rounded-2xl overflow-hidden bg-[#FCEEE9]">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#2C1A14]/80 via-[#2C1A14]/15 to-transparent opacity-90 group-hover:opacity-100 transition-opacity" />

                  <div className="absolute top-3 left-3">
                    <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-[#FFFBF7]/90 text-[#2C1A14]">
                      {item.category}
                    </span>
                  </div>

                  <div className="absolute bottom-4 left-4 right-4 text-[#FFFBF7]">
                    <h3 className="font-editorial text-2xl font-bold leading-snug">
                      {item.title}
                    </h3>
                    <p className="text-xs text-[#FCEEE9] mt-1">
                      {item.caption}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox Modal for Gallery Item */}
      {lightboxItem && (
        <div
          className="fixed inset-0 z-50 bg-[#2C1A14]/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightboxItem(null)}
        >
          <div
            className="bg-[#FFFBF7] rounded-3xl max-w-3xl w-full overflow-hidden border border-[#EBD8D0] shadow-2xl grid grid-cols-1 md:grid-cols-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="h-80 md:h-auto bg-[#FCEEE9]">
              <img
                src={lightboxItem.imageUrl}
                alt={lightboxItem.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-7 flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#FCEEE9] text-[#8C5843]">
                    {lightboxItem.category}
                  </span>
                  <button
                    type="button"
                    onClick={() => setLightboxItem(null)}
                    className="p-1.5 rounded-full bg-[#FCEEE9] text-[#2C1A14] hover:bg-[#D87A88] hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <h3 className="font-editorial text-3xl font-bold text-[#2C1A14]">
                  {lightboxItem.title}
                </h3>
                <p className="text-sm text-[#6E5249] leading-relaxed">
                  {lightboxItem.caption}. Handcrafted in the BIOBUK Atelier with
                  customizable sponge flavors, dietary options, and personalized
                  calligraphy.
                </p>
              </div>

              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={() => {
                    const matched = products.find(
                      (p) =>
                        p.category.toLowerCase() ===
                        lightboxItem.category.toLowerCase()
                    );
                    if (matched) {
                      handleSelectProductForOrder(matched);
                    }
                    setLightboxItem(null);
                  }}
                  className="w-full py-3.5 rounded-full bg-[#2C1A14] text-[#FFFBF7] text-xs font-semibold uppercase tracking-wider hover:bg-[#D87A88] transition-colors"
                >
                  Request This Design in Order Studio
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          6. ONLINE ORDERING STUDIO + FUNCTIONAL WHATSAPP ORDERING
      ========================================================= */}
      <section
        id="order-studio"
        className="py-20 lg:py-28 bg-gradient-to-b from-[#FCEEE9]/60 via-[#FFFBF7] to-[#FCEEE9]/40 border-b border-[#EBD8D0]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#D87A88]/40 text-[#8C5843] text-xs font-semibold uppercase tracking-[0.18em]">
              <ShoppingBag className="w-3.5 h-3.5 text-[#D87A88]" />
              Bespoke Online Ordering Studio
            </div>
            <h2 className="font-editorial text-3xl sm:text-5xl font-bold text-[#2C1A14]">
              Order Your Cake or Pastry
            </h2>
            <p className="text-base text-[#6E5249]">
              Customize your treat below and place your order directly on our
              website or send it straight to our{" "}
              <strong className="text-[#2C1A14]">BIOBUK WhatsApp Concierge</strong>{" "}
              with one click.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            {/* Left Column (7 cols): Interactive Order Form */}
            <form
              onSubmit={handleWebsiteOrderSubmit}
              className="lg:col-span-7 bg-white rounded-3xl border border-[#EBD8D0] p-6 sm:p-10 patisserie-shadow space-y-7"
            >
              <div className="border-b border-[#EBD8D0] pb-4 flex items-center justify-between">
                <div>
                  <h3 className="font-editorial text-2xl font-bold text-[#2C1A14]">
                    1. Guest &amp; Celebration Details
                  </h3>
                  <p className="text-xs text-[#6E5249]">
                    We will use these details to confirm your order and pickup/delivery time.
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#D87A88] bg-[#FCEEE9] px-3 py-1 rounded-full">
                  Instant Quote
                </span>
              </div>

              {orderError && (
                <div className="p-4 rounded-2xl bg-[#B43E3E]/10 border border-[#B43E3E]/30 text-[#B43E3E] text-sm font-medium">
                  {orderError}
                </div>
              )}

              {/* Customer Name & Phone Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label
                    htmlFor="order-customer-name"
                    className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                  >
                    Your Full Name *
                  </label>
                  <input
                    id="order-customer-name"
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Chidinma Adebayo"
                    className="w-full h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="order-customer-phone"
                    className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                  >
                    Phone / WhatsApp Number *
                  </label>
                  <input
                    id="order-customer-phone"
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. +234 809 555 0192"
                    className="w-full h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                  />
                </div>
              </div>

              {/* Select a Cake or Pastry */}
              <div className="pt-2 border-t border-[#EBD8D0]">
                <h3 className="font-editorial text-2xl font-bold text-[#2C1A14] mb-4">
                  2. Select Your Cake or Pastry
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="sm:col-span-2">
                    <label
                      htmlFor="order-product-select"
                      className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                    >
                      Choose a BIOBUK Creation *
                    </label>
                    <select
                      id="order-product-select"
                      value={selectedProductId}
                      onChange={(e) =>
                        setSelectedProductId(Number(e.target.value))
                      }
                      className="w-full h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm font-medium text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                    >
                      {products.map((prod) => (
                        <option key={prod.id} value={prod.id}>
                          {prod.category} — {prod.name} (Base: ${prod.basePrice}
                          )
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Cake Size Selector */}
                  <div>
                    <label
                      htmlFor="order-size-select"
                      className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                    >
                      Cake Size / Box Option *
                    </label>
                    <select
                      id="order-size-select"
                      value={cakeSize}
                      onChange={(e) => setCakeSize(e.target.value)}
                      className="w-full h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                    >
                      {SIZE_OPTIONS.map((sz) => (
                        <option key={sz.label} value={sz.label}>
                          {sz.label} ({sz.badge})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Quantity Stepper */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2">
                      Quantity *
                    </label>
                    <div className="h-12 px-3 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        className="w-8 h-8 rounded-lg bg-[#FCEEE9] text-[#2C1A14] hover:bg-[#D87A88] hover:text-white flex items-center justify-center transition-colors"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="font-price text-base font-bold text-[#2C1A14]">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => setQuantity((q) => Math.min(50, q + 1))}
                        className="w-8 h-8 rounded-lg bg-[#FCEEE9] text-[#2C1A14] hover:bg-[#D87A88] hover:text-white flex items-center justify-center transition-colors"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Signature Flavor Profile */}
                  <div className="sm:col-span-2">
                    <label
                      htmlFor="order-flavor-select"
                      className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                    >
                      Flavor Profile / Filling Selection
                    </label>
                    <select
                      id="order-flavor-select"
                      value={flavorChoice}
                      onChange={(e) => setFlavorChoice(e.target.value)}
                      className="w-full h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                    >
                      {FLAVOR_OPTIONS.map((flav) => (
                        <option key={flav} value={flav}>
                          {flav}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Pickup or Delivery + Preferred Date + Special Instructions */}
              <div className="pt-2 border-t border-[#EBD8D0] space-y-5">
                <h3 className="font-editorial text-2xl font-bold text-[#2C1A14]">
                  3. Fulfillment &amp; Preferred Date
                </h3>

                {/* Segmented Toggle: Pickup vs Delivery */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2">
                    Select Pickup or Delivery *
                  </label>
                  <div className="grid grid-cols-2 gap-3 p-1.5 rounded-2xl bg-[#FCEEE9]/60 border border-[#EBD8D0]">
                    <button
                      type="button"
                      onClick={() => setFulfillmentType("Pickup")}
                      className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all ${
                        fulfillmentType === "Pickup"
                          ? "bg-[#2C1A14] text-[#FFFBF7] shadow-sm"
                          : "text-[#6E5249] hover:text-[#2C1A14]"
                      }`}
                    >
                      <Store className="w-4 h-4 text-[#D87A88]" />
                      Atelier Pickup (Free)
                    </button>

                    <button
                      type="button"
                      onClick={() => setFulfillmentType("Delivery")}
                      className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all ${
                        fulfillmentType === "Delivery"
                          ? "bg-[#2C1A14] text-[#FFFBF7] shadow-sm"
                          : "text-[#6E5249] hover:text-[#2C1A14]"
                      }`}
                    >
                      <Truck className="w-4 h-4 text-[#D87A88]" />
                      Chilled Delivery (+$15)
                    </button>
                  </div>
                </div>

                {/* Conditional Delivery Address Input */}
                {fulfillmentType === "Delivery" && (
                  <div>
                    <label
                      htmlFor="order-delivery-address"
                      className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                    >
                      Delivery Street Address &amp; Landmark *
                    </label>
                    <input
                      id="order-delivery-address"
                      type="text"
                      required
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="e.g. 14 Admiralty Way, Lekki Phase 1 (Opposite Art Gallery)"
                      className="w-full h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                    />
                  </div>
                )}

                {/* Preferred Date & Time */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="order-preferred-date"
                      className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                    >
                      Preferred Date *
                    </label>
                    <div className="relative">
                      <input
                        id="order-preferred-date"
                        type="date"
                        required
                        value={preferredDate}
                        onChange={(e) => setPreferredDate(e.target.value)}
                        className="w-full h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="order-preferred-time"
                      className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                    >
                      Preferred Time Window
                    </label>
                    <select
                      id="order-preferred-time"
                      value={preferredTime}
                      onChange={(e) => setPreferredTime(e.target.value)}
                      className="w-full h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                    >
                      <option value="10:00 AM">Morning (10:00 AM – 12:00 PM)</option>
                      <option value="2:00 PM">Afternoon (12:00 PM – 3:00 PM)</option>
                      <option value="5:00 PM">Evening (3:00 PM – 6:00 PM)</option>
                    </select>
                  </div>
                </div>

                {/* Special Instructions */}
                <div>
                  <label
                    htmlFor="order-special-instructions"
                    className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-2"
                  >
                    Special Instructions (Inscription, Color Palette, Dietary Notes)
                  </label>
                  <textarea
                    id="order-special-instructions"
                    rows={3}
                    value={specialInstructions}
                    onChange={(e) => setSpecialInstructions(e.target.value)}
                    placeholder="e.g. Write 'Happy Birthday Queen Zara' in gold calligraphy; soft pink and cream roses; nut-free sponge."
                    className="w-full p-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
                  />
                </div>
              </div>

              {/* Dual Submission Buttons: Website Order + Functional WhatsApp Ordering Button */}
              <div className="pt-4 border-t border-[#EBD8D0] flex flex-col sm:flex-row gap-4">
                <button
                  type="submit"
                  disabled={submittingOrder}
                  className="flex-1 py-4 px-6 rounded-full bg-[#2C1A14] text-[#FFFBF7] hover:bg-[#8C5843] text-xs sm:text-sm font-semibold uppercase tracking-wider shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4 text-[#D87A88]" />
                  {submittingOrder
                    ? "Confirming Order..."
                    : `Confirm Website Order ($${pricingSummary.total})`}
                </button>

                <button
                  type="button"
                  disabled={submittingOrder}
                  onClick={handleWhatsAppOrder}
                  className="flex-1 py-4 px-6 rounded-full bg-[#2E6F40] text-white hover:bg-[#235732] text-xs sm:text-sm font-semibold uppercase tracking-wider shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  Order via WhatsApp
                  <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                </button>
              </div>
            </form>

            {/* Right Column (5 cols): Live Order Summary & Instant Confirmation Card */}
            <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
              {/* Live Receipt Card */}
              <div className="bg-white rounded-3xl border border-[#EBD8D0] p-6 sm:p-8 patisserie-shadow space-y-6">
                <div className="flex items-center gap-4 border-b border-[#EBD8D0] pb-5">
                  <img
                    src={selectedProduct.imageUrl || "/images/hero-cake.jpg"}
                    alt={selectedProduct.name}
                    className="w-20 h-20 rounded-2xl object-cover border border-[#EBD8D0]"
                  />
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#D87A88]">
                      {selectedProduct.category}
                    </span>
                    <h4 className="font-editorial text-2xl font-bold text-[#2C1A14] leading-tight">
                      {selectedProduct.name}
                    </h4>
                    <p className="text-xs text-[#6E5249] mt-1">
                      Base Price: ${selectedProduct.basePrice}
                    </p>
                  </div>
                </div>

                {/* Breakdown Lines */}
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between gap-4">
                    <span className="text-[#6E5249]">Selected Size:</span>
                    <span className="font-medium text-[#2C1A14] text-right">
                      {cakeSize}
                    </span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-[#6E5249]">Flavor Profile:</span>
                    <span className="font-medium text-[#2C1A14] text-right">
                      {flavorChoice}
                    </span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-[#6E5249]">Unit Price × Qty:</span>
                    <span className="font-price font-semibold text-[#2C1A14]">
                      ${pricingSummary.unitPrice} × {quantity} = $
                      {pricingSummary.subtotal}
                    </span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-[#6E5249]">
                      Fulfillment ({fulfillmentType}):
                    </span>
                    <span className="font-price font-semibold text-[#2C1A14]">
                      {fulfillmentType === "Delivery" ? "$15" : "FREE"}
                    </span>
                  </div>
                  <div className="flex justify-between gap-4">
                    <span className="text-[#6E5249]">Preferred Date:</span>
                    <span className="font-medium text-[#2C1A14]">
                      {preferredDate} • {preferredTime}
                    </span>
                  </div>
                </div>

                {/* Total Bar */}
                <div className="p-4 rounded-2xl bg-[#FCEEE9] border border-[#D87A88]/40 flex items-center justify-between">
                  <div>
                    <span className="text-xs uppercase tracking-wider font-bold text-[#8C5843] block">
                      Estimated Total
                    </span>
                    <span className="text-[11px] text-[#6E5249]">
                      Payable upon confirmation
                    </span>
                  </div>
                  <span className="font-price text-3xl font-bold text-[#2C1A14]">
                    ${pricingSummary.total}
                  </span>
                </div>

                {/* Copy WhatsApp Order Text Helper */}
                <div className="pt-1 flex items-center justify-between gap-2 text-xs text-[#6E5249]">
                  <span>Prefer to paste into WhatsApp manually?</span>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyWhatsAppMessage(confirmedOrder?.orderReference)
                    }
                    className="inline-flex items-center gap-1.5 font-semibold text-[#2C1A14] underline decoration-[#D87A88] underline-offset-4 hover:text-[#D87A88]"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {copiedWhatsAppText ? "Copied!" : "Copy Order Summary"}
                  </button>
                </div>
              </div>

              {/* Instant Confirmed Order Ticket (Appears after submitting) */}
              {confirmedOrder && (
                <div className="bg-[#2C1A14] text-[#FFFBF7] rounded-3xl p-6 sm:p-7 border border-[#D87A88] shadow-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#2E6F40] text-white text-xs font-bold uppercase tracking-wider">
                      <Check className="w-3.5 h-3.5" />
                      Order Registered
                    </span>
                    <span className="font-price text-sm text-[#D87A88] font-bold">
                      Ref: {confirmedOrder.orderReference}
                    </span>
                  </div>

                  <h4 className="font-editorial text-2xl font-bold">
                    Thank You, {confirmedOrder.customerName}!
                  </h4>
                  <p className="text-xs text-[#EBD8D0] leading-relaxed">
                    Your order for{" "}
                    <strong className="text-white">
                      {confirmedOrder.quantity}× {confirmedOrder.productName}
                    </strong>{" "}
                    ({confirmedOrder.cakeSize}) scheduled for{" "}
                    <strong className="text-white">
                      {confirmedOrder.preferredDate}
                    </strong>{" "}
                    has been saved in the BIOBUK system.
                  </p>

                  <div className="pt-2 flex flex-wrap gap-3">
                    <a
                      href={`https://wa.me/${
                        BUSINESS_CONTACT.whatsappNumber
                      }?text=${encodeURIComponent(
                        buildWhatsAppMessage(confirmedOrder.orderReference)
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-3 px-4 rounded-full bg-[#2E6F40] text-white text-xs font-semibold uppercase tracking-wider text-center flex items-center justify-center gap-2 hover:bg-[#245832]"
                    >
                      <MessageCircle className="w-4 h-4" />
                      Send Reference on WhatsApp
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          8. EXTRA FEATURES: CUSTOMER TESTIMONIALS & FAQ
      ========================================================= */}
      <section
        id="testimonials"
        className="py-20 lg:py-28 bg-[#FFFBF7] border-b border-[#EBD8D0]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
          {/* Customer Testimonials */}
          <div>
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
              <div className="space-y-3 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FCEEE9] text-[#8C5843] text-xs font-semibold uppercase tracking-[0.18em]">
                  <Star className="w-3.5 h-3.5 text-[#D87A88] fill-[#D87A88]" />
                  Client Love Letters
                </div>
                <h2 className="font-editorial text-3xl sm:text-5xl font-bold text-[#2C1A14]">
                  Sweet Words from Our Celebrations
                </h2>
                <p className="text-base text-[#6E5249]">
                  Discover why brides, birthday hosts, and corporate clients
                  trust BIOBUK for their most cherished moments.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowReviewModal(true)}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#FCEEE9] text-[#2C1A14] border border-[#D87A88]/40 hover:bg-[#2C1A14] hover:text-white text-xs font-semibold uppercase tracking-wider transition-all self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                Share Your Review
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {testimonials.slice(0, 4).map((rev) => (
                <div
                  key={rev.id}
                  className="bg-white rounded-3xl p-6 border border-[#EBD8D0] patisserie-shadow flex flex-col justify-between space-y-5"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-[#C87D28]">
                        {Array.from({ length: rev.rating }).map((_, idx) => (
                          <Star
                            key={idx}
                            className="w-4 h-4 fill-[#C87D28] text-[#C87D28]"
                          />
                        ))}
                      </div>
                      <span className="text-[11px] font-semibold text-[#2E6F40] bg-[#2E6F40]/10 px-2.5 py-0.5 rounded-full">
                        Verified Order
                      </span>
                    </div>

                    <p className="text-sm text-[#2C1A14] leading-relaxed italic">
                      &ldquo;{rev.comment}&rdquo;
                    </p>
                  </div>

                  <div className="pt-4 border-t border-[#EBD8D0]">
                    <p className="font-editorial text-lg font-bold text-[#2C1A14]">
                      {rev.clientName}
                    </p>
                    <p className="text-xs text-[#8C5843] font-medium">
                      {rev.occasion} • {rev.productOrdered}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Frequently Asked Questions (FAQ) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5 space-y-4">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FCEEE9] text-[#8C5843] text-xs font-semibold uppercase tracking-[0.18em]">
                <Sparkles className="w-3.5 h-3.5 text-[#D87A88]" />
                Pâtisserie Concierge FAQ
              </div>
              <h2 className="font-editorial text-3xl sm:text-4xl font-bold text-[#2C1A14]">
                Frequently Asked Questions
              </h2>
              <p className="text-sm sm:text-base text-[#6E5249] leading-relaxed">
                Everything you need to know about ordering custom cakes,
                lead times, flavor tastings, and chilled delivery. Have a
                special request? Reach out directly via WhatsApp.
              </p>
              <div className="pt-2">
                <a
                  href={`https://wa.me/${BUSINESS_CONTACT.whatsappNumber}?text=${encodeURIComponent(
                    "Hi BIOBUK! I have a quick question about ordering a custom cake."
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-[#2C1A14] text-[#FFFBF7] text-xs font-semibold uppercase tracking-wider hover:bg-[#D87A88] transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-[#D87A88]" />
                  Ask Our Head Baker on WhatsApp
                </a>
              </div>
            </div>

            <div className="lg:col-span-7 space-y-3.5">
              {FAQ_ITEMS.map((faq, index) => {
                const isOpen = openFaqIndex === index;
                return (
                  <div
                    key={faq.question}
                    className="bg-white rounded-2xl border border-[#EBD8D0] overflow-hidden transition-all"
                  >
                    <button
                      type="button"
                      onClick={() =>
                        setOpenFaqIndex(isOpen ? null : index)
                      }
                      className="w-full px-6 py-5 text-left flex items-center justify-between gap-4 hover:bg-[#FCEEE9]/30 transition-colors"
                    >
                      <span className="font-editorial text-xl font-bold text-[#2C1A14]">
                        {faq.question}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-[#8C5843] shrink-0 transition-transform duration-300 ${
                          isOpen ? "rotate-180 text-[#D87A88]" : ""
                        }`}
                      />
                    </button>
                    {isOpen && (
                      <div className="px-6 pb-5 pt-1 text-sm text-[#6E5249] leading-relaxed border-t border-[#EBD8D0]/50">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          7. CONTACT INFORMATION SECTION
      ========================================================= */}
      <section
        id="contact"
        className="py-20 lg:py-28 bg-gradient-to-b from-[#FFFBF7] to-[#FCEEE9]/60 border-b border-[#EBD8D0]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FCEEE9] text-[#8C5843] text-xs font-semibold uppercase tracking-[0.18em]">
              <MapPin className="w-3.5 h-3.5 text-[#D87A88]" />
              Visit or Connect With BIOBUK
            </div>
            <h2 className="font-editorial text-3xl sm:text-5xl font-bold text-[#2C1A14]">
              Contact Our Bakery Salon
            </h2>
            <p className="text-base text-[#6E5249]">
              Reach out by phone, WhatsApp, email, or Instagram, or visit our
              flagship bakery salon for cake tastings and fresh daily boxes.
            </p>
          </div>

          {/* 5 Required Contact Information Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5 mb-14">
            {/* 1. Phone Number */}
            <div className="bg-white rounded-3xl p-6 border border-[#EBD8D0] patisserie-shadow flex flex-col justify-between space-y-4">
              <div className="w-11 h-11 rounded-2xl bg-[#FCEEE9] flex items-center justify-center text-[#2C1A14]">
                <Phone className="w-5 h-5 text-[#D87A88]" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider font-bold text-[#8C5843]">
                  Phone Number
                </p>
                <a
                  href={`tel:${BUSINESS_CONTACT.phoneRaw}`}
                  className="font-editorial text-xl font-bold text-[#2C1A14] hover:text-[#D87A88] block mt-1"
                >
                  {BUSINESS_CONTACT.phoneDisplay}
                </a>
                <p className="text-xs text-[#6E5249] mt-1">
                  Direct Bakery Desk
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleCopyContact(
                    "Phone Number",
                    BUSINESS_CONTACT.phoneDisplay
                  )
                }
                className="text-xs font-semibold text-[#8C5843] hover:text-[#2C1A14] inline-flex items-center gap-1"
              >
                <Copy className="w-3.5 h-3.5" />
                {copiedContactField === "Phone Number"
                  ? "Copied!"
                  : "Copy Number"}
              </button>
            </div>

            {/* 2. WhatsApp Number */}
            <div className="bg-white rounded-3xl p-6 border border-[#EBD8D0] patisserie-shadow flex flex-col justify-between space-y-4">
              <div className="w-11 h-11 rounded-2xl bg-[#2E6F40]/10 flex items-center justify-center text-[#2E6F40]">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider font-bold text-[#8C5843]">
                  WhatsApp Number
                </p>
                <a
                  href={`https://wa.me/${BUSINESS_CONTACT.whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-editorial text-xl font-bold text-[#2C1A14] hover:text-[#2E6F40] block mt-1"
                >
                  {BUSINESS_CONTACT.whatsappDisplay}
                </a>
                <p className="text-xs text-[#6E5249] mt-1">
                  Instant Cake Orders &amp; Chat
                </p>
              </div>
              <a
                href={`https://wa.me/${BUSINESS_CONTACT.whatsappNumber}?text=${encodeURIComponent(
                  "Hello BIOBUK! I'd like to place an order."
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-semibold text-[#2E6F40] hover:underline inline-flex items-center gap-1"
              >
                Chat Now <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            {/* 3. Email Address */}
            <div className="bg-white rounded-3xl p-6 border border-[#EBD8D0] patisserie-shadow flex flex-col justify-between space-y-4">
              <div className="w-11 h-11 rounded-2xl bg-[#FCEEE9] flex items-center justify-center text-[#2C1A14]">
                <Mail className="w-5 h-5 text-[#D87A88]" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider font-bold text-[#8C5843]">
                  Email Address
                </p>
                <a
                  href={`mailto:${BUSINESS_CONTACT.email}`}
                  className="font-editorial text-lg font-bold text-[#2C1A14] hover:text-[#D87A88] block mt-1 break-all"
                >
                  {BUSINESS_CONTACT.email}
                </a>
                <p className="text-xs text-[#6E5249] mt-1">
                  Weddings &amp; Corporate Events
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleCopyContact("Email Address", BUSINESS_CONTACT.email)
                }
                className="text-xs font-semibold text-[#8C5843] hover:text-[#2C1A14] inline-flex items-center gap-1"
              >
                <Copy className="w-3.5 h-3.5" />
                {copiedContactField === "Email Address"
                  ? "Copied!"
                  : "Copy Email"}
              </button>
            </div>

            {/* 4. Instagram Account */}
            <div className="bg-white rounded-3xl p-6 border border-[#EBD8D0] patisserie-shadow flex flex-col justify-between space-y-4">
              <div className="w-11 h-11 rounded-2xl bg-[#FCEEE9] flex items-center justify-center text-[#2C1A14]">
                <Instagram className="w-5 h-5 text-[#D87A88]" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider font-bold text-[#8C5843]">
                  Instagram Account
                </p>
                <a
                  href={BUSINESS_CONTACT.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-editorial text-xl font-bold text-[#2C1A14] hover:text-[#D87A88] block mt-1"
                >
                  {BUSINESS_CONTACT.instagramHandle}
                </a>
                <p className="text-xs text-[#6E5249] mt-1">
                  Daily Cake Reels &amp; Lookbook
                </p>
              </div>
              <a
                href={BUSINESS_CONTACT.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-semibold text-[#D87A88] hover:underline inline-flex items-center gap-1"
              >
                Follow Us <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            {/* 5. Business Location */}
            <div className="bg-white rounded-3xl p-6 border border-[#EBD8D0] patisserie-shadow flex flex-col justify-between space-y-4">
              <div className="w-11 h-11 rounded-2xl bg-[#FCEEE9] flex items-center justify-center text-[#2C1A14]">
                <MapPin className="w-5 h-5 text-[#D87A88]" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider font-bold text-[#8C5843]">
                  Business Location
                </p>
                <p className="font-editorial text-lg font-bold text-[#2C1A14] mt-1 leading-snug">
                  {BUSINESS_CONTACT.location}
                </p>
                <p className="text-[11px] text-[#6E5249] mt-1">
                  {BUSINESS_CONTACT.hours}
                </p>
              </div>
              <a
                href="#order-studio"
                className="text-xs font-semibold text-[#8C5843] hover:text-[#2C1A14] inline-flex items-center gap-1"
              >
                Schedule Pickup <ChevronRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Direct Inquiry & Bespoke Consultation Card */}
          <div className="bg-white rounded-3xl border border-[#EBD8D0] p-6 sm:p-10 patisserie-shadow grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5 space-y-4">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#D87A88]">
                Private Cake Tasting &amp; Event Desk
              </span>
              <h3 className="font-editorial text-3xl font-bold text-[#2C1A14]">
                Planning a Wedding or Grand Milestone?
              </h3>
              <p className="text-sm text-[#6E5249] leading-relaxed">
                Send a note to our Head Pâtissier to book a private tasting box
                or request a custom event quote for weddings, birthdays, and
                corporate gifting.
              </p>
              <div className="p-4 rounded-2xl bg-[#FCEEE9]/60 border border-[#EBD8D0] space-y-1.5 text-xs text-[#2C1A14]">
                <p className="font-bold">Atelier Tasting Hours:</p>
                <p className="text-[#6E5249]">{BUSINESS_CONTACT.hours}</p>
              </div>
            </div>

            <form
              onSubmit={handleContactSubmit}
              className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4"
            >
              {contactSuccess && (
                <div className="sm:col-span-2 p-4 rounded-2xl bg-[#2E6F40]/10 border border-[#2E6F40]/30 text-[#2E6F40] text-sm font-medium">
                  Thank you! Your inquiry has been logged with our Concierge
                  Desk. We will contact you shortly.
                </div>
              )}
              <input
                type="text"
                required
                value={contactForm.name}
                onChange={(e) =>
                  setContactForm({ ...contactForm, name: e.target.value })
                }
                placeholder="Your Name *"
                className="h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
              />
              <input
                type="tel"
                required
                value={contactForm.phone}
                onChange={(e) =>
                  setContactForm({ ...contactForm, phone: e.target.value })
                }
                placeholder="Phone / WhatsApp Number *"
                className="h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
              />
              <input
                type="email"
                value={contactForm.email}
                onChange={(e) =>
                  setContactForm({ ...contactForm, email: e.target.value })
                }
                placeholder="Email Address (Optional)"
                className="h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
              />
              <input
                type="text"
                value={contactForm.subject}
                onChange={(e) =>
                  setContactForm({ ...contactForm, subject: e.target.value })
                }
                placeholder="Occasion / Subject"
                className="h-12 px-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
              />
              <textarea
                rows={3}
                required
                value={contactForm.message}
                onChange={(e) =>
                  setContactForm({ ...contactForm, message: e.target.value })
                }
                placeholder="Tell us about your celebration date, guest count, or flavor preferences... *"
                className="sm:col-span-2 p-4 rounded-xl bg-[#FFFBF7] border border-[#EBD8D0] text-sm text-[#2C1A14] focus:outline-none focus:border-[#D87A88]"
              />
              <div className="sm:col-span-2">
                <button
                  type="submit"
                  disabled={sendingContact}
                  className="px-8 py-3.5 rounded-full bg-[#2C1A14] text-[#FFFBF7] hover:bg-[#D87A88] text-xs font-semibold uppercase tracking-wider transition-colors inline-flex items-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  {sendingContact ? "Sending..." : "Send Consultation Request"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* =========================================================
          9. FOOTER SECTION
      ========================================================= */}
      <footer className="bg-[#2C1A14] text-[#FCEEE9] pt-16 pb-12 border-t border-[#8C5843]/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-[#8C5843]/30">
            {/* Brand Column (4 cols) */}
            <div className="lg:col-span-4 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#D87A88] flex items-center justify-center text-white">
                  <Cake className="w-5 h-5" />
                </div>
                <div>
                  <span className="font-editorial text-3xl font-bold tracking-[0.22em] text-white block leading-none">
                    BIOBUK
                  </span>
                  <span className="text-[10px] uppercase tracking-[0.25em] text-[#D87A88] font-semibold">
                    Haute Pâtisserie &amp; Bakery
                  </span>
                </div>
              </div>
              <p className="text-sm text-[#EBD8D0]/80 leading-relaxed max-w-sm">
                &ldquo;Baking Happiness, One Treat at a Time.&rdquo; Handcrafted
                celebration cakes, wedding tiers, cupcakes, brioche doughnuts,
                small chops, and French pastries baked fresh daily.
              </p>
              <div className="flex items-center gap-3 pt-2">
                <a
                  href={BUSINESS_CONTACT.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="BIOBUK Instagram"
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-[#D87A88] flex items-center justify-center text-white transition-colors"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href={`https://wa.me/${BUSINESS_CONTACT.whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="BIOBUK WhatsApp"
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-[#2E6F40] flex items-center justify-center text-white transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
                <a
                  href={`mailto:${BUSINESS_CONTACT.email}`}
                  aria-label="BIOBUK Email"
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-[#D87A88] flex items-center justify-center text-white transition-colors"
                >
                  <Mail className="w-4 h-4" />
                </a>
                <a
                  href={`tel:${BUSINESS_CONTACT.phoneRaw}`}
                  aria-label="BIOBUK Phone"
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-[#D87A88] flex items-center justify-center text-white transition-colors"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Collections Column (3 cols) */}
            <div className="lg:col-span-3 space-y-3">
              <h4 className="font-editorial text-xl font-bold text-white">
                Our Collections
              </h4>
              <ul className="space-y-2 text-sm text-[#EBD8D0]/80">
                {PRODUCT_CATEGORIES.filter((c) => c !== "All").map((cat) => (
                  <li key={cat}>
                    <a
                      href="#products"
                      onClick={() => setActiveCategory(cat)}
                      className="hover:text-[#D87A88] transition-colors"
                    >
                      {cat}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Quick Links Column (2 cols) */}
            <div className="lg:col-span-2 space-y-3">
              <h4 className="font-editorial text-xl font-bold text-white">
                Explore
              </h4>
              <ul className="space-y-2 text-sm text-[#EBD8D0]/80">
                <li>
                  <a href="#top" className="hover:text-[#D87A88]">
                    Home
                  </a>
                </li>
                <li>
                  <a href="#about" className="hover:text-[#D87A88]">
                    About BIOBUK
                  </a>
                </li>
                <li>
                  <a href="#products" className="hover:text-[#D87A88]">
                    Our Products
                  </a>
                </li>
                <li>
                  <a href="#gallery" className="hover:text-[#D87A88]">
                    Cake Gallery
                  </a>
                </li>
                <li>
                  <a href="#order-studio" className="hover:text-[#D87A88]">
                    Online Ordering
                  </a>
                </li>
                <li>
                  <a href="#testimonials" className="hover:text-[#D87A88]">
                    Testimonials &amp; FAQ
                  </a>
                </li>
                <li>
                  <a href="#contact" className="hover:text-[#D87A88]">
                    Contact Us
                  </a>
                </li>
              </ul>
            </div>

            {/* Contact Details Column (3 cols) */}
            <div className="lg:col-span-3 space-y-3 text-sm text-[#EBD8D0]/85">
              <h4 className="font-editorial text-xl font-bold text-white">
                Visit Our Salon
              </h4>
              <p className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#D87A88] shrink-0 mt-1" />
                <span>{BUSINESS_CONTACT.location}</span>
              </p>
              <p className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#D87A88] shrink-0" />
                <span>{BUSINESS_CONTACT.phoneDisplay}</span>
              </p>
              <p className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#D87A88] shrink-0" />
                <span>WhatsApp: {BUSINESS_CONTACT.whatsappDisplay}</span>
              </p>
              <p className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#D87A88] shrink-0" />
                <span>{BUSINESS_CONTACT.email}</span>
              </p>
              <p className="flex items-center gap-2.5">
                <Instagram className="w-4 h-4 text-[#D87A88] shrink-0" />
                <span>{BUSINESS_CONTACT.instagramHandle}</span>
              </p>
            </div>
          </div>

          {/* Copyright Bottom Bar */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#EBD8D0]/70">
            <p>
              © {new Date().getFullYear()} <strong className="text-white">BIOBUK</strong> Haute Pâtisserie &amp; Artisanal Bakery. All rights reserved.
            </p>
            <p className="flex items-center gap-1.5">
              Handcrafted with <Heart className="w-3.5 h-3.5 text-[#D87A88] fill-[#D87A88]" /> Soft Pink, Cream &amp; Roasted Espresso
            </p>
          </div>
        </div>
      </footer>

      {/* =========================================================
          MODALS: ADD PRODUCT, SUBMIT REVIEW, ORDER TRACKER
      ========================================================= */}
      {/* Add New Product Modal */}
      {showAddProductModal && (
        <div
          className="fixed inset-0 z-50 bg-[#2C1A14]/75 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setShowAddProductModal(false)}
        >
          <div
            className="bg-[#FFFBF7] rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-[#EBD8D0] shadow-2xl space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-editorial text-2xl font-bold text-[#2C1A14]">
                Add New BIOBUK Creation
              </h3>
              <button
                type="button"
                onClick={() => setShowAddProductModal(false)}
                className="p-1.5 rounded-full bg-[#FCEEE9] text-[#2C1A14]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateNewProduct} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  value={newProductForm.name}
                  onChange={(e) =>
                    setNewProductForm({
                      ...newProductForm,
                      name: e.target.value,
                    })
                  }
                  placeholder="e.g. Strawberry Champagne Opera Cake"
                  className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#EBD8D0] text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                    Category *
                  </label>
                  <select
                    value={newProductForm.category}
                    onChange={(e) =>
                      setNewProductForm({
                        ...newProductForm,
                        category: e.target.value,
                      })
                    }
                    className="w-full h-11 px-3 rounded-xl bg-white border border-[#EBD8D0] text-sm"
                  >
                    {PRODUCT_CATEGORIES.filter((c) => c !== "All").map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                    Price (USD $) *
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={newProductForm.basePrice}
                    onChange={(e) =>
                      setNewProductForm({
                        ...newProductForm,
                        basePrice: e.target.value,
                      })
                    }
                    className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#EBD8D0] text-sm font-price"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                  Description *
                </label>
                <textarea
                  rows={3}
                  required
                  value={newProductForm.description}
                  onChange={(e) =>
                    setNewProductForm({
                      ...newProductForm,
                      description: e.target.value,
                    })
                  }
                  placeholder="Describe the sponge, buttercream, and artisanal garnishes..."
                  className="w-full p-3.5 rounded-xl bg-white border border-[#EBD8D0] text-sm"
                />
              </div>

              <button
                type="submit"
                disabled={creatingProduct}
                className="w-full py-3.5 rounded-full bg-[#2C1A14] text-[#FFFBF7] text-xs font-semibold uppercase tracking-wider hover:bg-[#D87A88] transition-colors"
              >
                {creatingProduct ? "Saving to Menu..." : "Save Product to Menu"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Share Customer Review Modal */}
      {showReviewModal && (
        <div
          className="fixed inset-0 z-50 bg-[#2C1A14]/75 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setShowReviewModal(false)}
        >
          <div
            className="bg-[#FFFBF7] rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-[#EBD8D0] shadow-2xl space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-editorial text-2xl font-bold text-[#2C1A14]">
                Share Your BIOBUK Experience
              </h3>
              <button
                type="button"
                onClick={() => setShowReviewModal(false)}
                className="p-1.5 rounded-full bg-[#FCEEE9] text-[#2C1A14]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                  Your Name *
                </label>
                <input
                  type="text"
                  required
                  value={reviewForm.clientName}
                  onChange={(e) =>
                    setReviewForm({ ...reviewForm, clientName: e.target.value })
                  }
                  placeholder="e.g. Zainab Bello"
                  className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#EBD8D0] text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                    Celebration Occasion
                  </label>
                  <input
                    type="text"
                    value={reviewForm.occasion}
                    onChange={(e) =>
                      setReviewForm({ ...reviewForm, occasion: e.target.value })
                    }
                    placeholder="e.g. Bridal Shower"
                    className="w-full h-11 px-3.5 rounded-xl bg-white border border-[#EBD8D0] text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                    Rating
                  </label>
                  <select
                    value={reviewForm.rating}
                    onChange={(e) =>
                      setReviewForm({
                        ...reviewForm,
                        rating: Number(e.target.value),
                      })
                    }
                    className="w-full h-11 px-3 rounded-xl bg-white border border-[#EBD8D0] text-sm"
                  >
                    <option value={5}>5 Stars (Exceptional)</option>
                    <option value={4}>4 Stars (Wonderful)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#2C1A14] mb-1">
                  Your Review *
                </label>
                <textarea
                  rows={3}
                  required
                  value={reviewForm.comment}
                  onChange={(e) =>
                    setReviewForm({ ...reviewForm, comment: e.target.value })
                  }
                  placeholder="Tell us what you loved about your cake or pastry..."
                  className="w-full p-3.5 rounded-xl bg-white border border-[#EBD8D0] text-sm"
                />
              </div>

              <button
                type="submit"
                disabled={submittingReview}
                className="w-full py-3.5 rounded-full bg-[#2C1A14] text-[#FFFBF7] text-xs font-semibold uppercase tracking-wider hover:bg-[#D87A88] transition-colors"
              >
                {submittingReview ? "Publishing..." : "Publish Review"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Live Order Tracker Modal */}
      {showOrderTrackerModal && (
        <div
          className="fixed inset-0 z-50 bg-[#2C1A14]/75 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setShowOrderTrackerModal(false)}
        >
          <div
            className="bg-[#FFFBF7] rounded-3xl max-w-2xl w-full p-6 sm:p-8 border border-[#EBD8D0] shadow-2xl space-y-5 max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-[#EBD8D0] pb-4">
              <div>
                <h3 className="font-editorial text-2xl font-bold text-[#2C1A14]">
                  BIOBUK Live Order Queue
                </h3>
                <p className="text-xs text-[#6E5249]">
                  Track your recent celebration order or view bakery status.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowOrderTrackerModal(false)}
                className="p-1.5 rounded-full bg-[#FCEEE9] text-[#2C1A14]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-[#8C5843] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={lookupReference}
                onChange={(e) => setLookupReference(e.target.value)}
                placeholder="Filter by Order Reference (e.g. BBK-2026-...) or Name"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-[#EBD8D0] text-sm"
              />
            </div>

            <div className="space-y-3">
              {recentOrders
                .filter(
                  (o) =>
                    !lookupReference.trim() ||
                    o.orderReference
                      .toLowerCase()
                      .includes(lookupReference.toLowerCase()) ||
                    o.customerName
                      .toLowerCase()
                      .includes(lookupReference.toLowerCase())
                )
                .map((ord) => (
                  <div
                    key={ord.id}
                    className="p-4 rounded-2xl bg-white border border-[#EBD8D0] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-price text-xs font-bold text-[#8C5843] bg-[#FCEEE9] px-2.5 py-0.5 rounded-full">
                          {ord.orderReference}
                        </span>
                        <span className="text-xs font-semibold text-[#2E6F40]">
                          • {ord.status}
                        </span>
                      </div>
                      <p className="font-editorial text-lg font-bold text-[#2C1A14]">
                        {ord.quantity}× {ord.productName}
                      </p>
                      <p className="text-xs text-[#6E5249]">
                        Guest: {ord.customerName} • {ord.fulfillmentType} on{" "}
                        {ord.preferredDate}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="font-price text-lg font-bold text-[#2C1A14] block">
                        ${ord.totalPrice}
                      </span>
                      <span className="text-[11px] text-[#6E5249]">
                        {ord.cakeSize}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
