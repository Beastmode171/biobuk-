import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { testimonials } from "@/db/schema";
import { ensureSeeded } from "@/db/seed-data";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();
    const list = await db
      .select()
      .from(testimonials)
      .orderBy(desc(testimonials.createdAt))
      .limit(12);

    return NextResponse.json({ testimonials: list });
  } catch (error) {
    console.error("GET /api/testimonials error:", error);
    return NextResponse.json(
      { error: "Failed to load testimonials." },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const { clientName, occasion, rating, comment, productOrdered } = body;

    if (!clientName?.trim() || !comment?.trim()) {
      return NextResponse.json(
        { error: "Name and review comment are required." },
        { status: 400 }
      );
    }

    const numericRating = Math.min(5, Math.max(1, Number(rating) || 5));

    const [created] = await db
      .insert(testimonials)
      .values({
        clientName: clientName.trim(),
        occasion: occasion?.trim() || "Special Celebration",
        rating: numericRating,
        comment: comment.trim(),
        productOrdered: productOrdered?.trim() || "Signature BIOBUK Creation",
        verified: true,
      })
      .returning();

    return NextResponse.json({ testimonial: created }, { status: 201 });
  } catch (error) {
    console.error("POST /api/testimonials error:", error);
    return NextResponse.json(
      { error: "Failed to submit testimonial." },
      { status: 500 }
    );
  }
}
