import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { ensureSeeded } from "@/db/seed-data";

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const { name, phone, email, subject, message } = body;

    if (!name?.trim() || !phone?.trim() || !message?.trim()) {
      return NextResponse.json(
        { error: "Please provide your name, phone number, and message." },
        { status: 400 }
      );
    }

    const [saved] = await db
      .insert(contactMessages)
      .values({
        name: name.trim(),
        phone: phone.trim(),
        email: email?.trim() || null,
        subject: subject?.trim() || "Bespoke Bakery Inquiry",
        message: message.trim(),
      })
      .returning();

    return NextResponse.json({ message: saved }, { status: 201 });
  } catch (error) {
    console.error("POST /api/contact error:", error);
    return NextResponse.json(
      { error: "Failed to send message." },
      { status: 500 }
    );
  }
}
