import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { ensureSeeded } from "@/db/seed-data";
import { desc, eq } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    await ensureSeeded();
    const { searchParams } = new URL(request.url);
    const reference = searchParams.get("reference");

    if (reference) {
      const [found] = await db
        .select()
        .from(orders)
        .where(eq(orders.orderReference, reference.trim().toUpperCase()));
      return NextResponse.json({ order: found || null });
    }

    const recentOrders = await db
      .select()
      .from(orders)
      .orderBy(desc(orders.createdAt))
      .limit(20);

    return NextResponse.json({ orders: recentOrders });
  } catch (error) {
    console.error("GET /api/orders error:", error);
    return NextResponse.json(
      { error: "Failed to fetch orders." },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();

    const {
      customerName,
      customerPhone,
      customerEmail,
      productId,
      productName,
      productCategory,
      cakeSize,
      flavorChoice,
      quantity,
      fulfillmentType,
      deliveryAddress,
      preferredDate,
      preferredTime,
      specialInstructions,
      unitPrice,
      deliveryFee,
      totalPrice,
    } = body;

    if (
      !customerName?.trim() ||
      !customerPhone?.trim() ||
      !productName?.trim() ||
      !cakeSize?.trim() ||
      !fulfillmentType?.trim() ||
      !preferredDate?.trim()
    ) {
      return NextResponse.json(
        {
          error:
            "Please complete your name, phone number, treat selection, size, fulfillment method, and preferred date.",
        },
        { status: 400 }
      );
    }

    if (fulfillmentType === "Delivery" && !deliveryAddress?.trim()) {
      return NextResponse.json(
        { error: "Please provide a delivery address for delivery orders." },
        { status: 400 }
      );
    }

    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const orderReference = `BBK-2026-${randomDigits}`;

    const parsedQuantity = Math.max(1, Number(quantity) || 1);
    const parsedUnitPrice = Math.max(1, Number(unitPrice) || 50);
    const parsedDeliveryFee =
      fulfillmentType === "Delivery" ? Math.max(0, Number(deliveryFee) || 15) : 0;
    const calculatedTotal =
      Number(totalPrice) || parsedUnitPrice * parsedQuantity + parsedDeliveryFee;

    const [createdOrder] = await db
      .insert(orders)
      .values({
        orderReference,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerEmail: customerEmail?.trim() || null,
        productId: productId ? Number(productId) : null,
        productName: productName.trim(),
        productCategory: productCategory?.trim() || "Custom Selection",
        cakeSize: cakeSize.trim(),
        flavorChoice: flavorChoice?.trim() || "Signature Madagascar Vanilla",
        quantity: parsedQuantity,
        fulfillmentType: fulfillmentType.trim(),
        deliveryAddress:
          fulfillmentType === "Delivery" ? deliveryAddress?.trim() || null : null,
        preferredDate: preferredDate.trim(),
        preferredTime: preferredTime?.trim() || "12:00 PM",
        specialInstructions: specialInstructions?.trim() || null,
        unitPrice: parsedUnitPrice,
        deliveryFee: parsedDeliveryFee,
        totalPrice: calculatedTotal,
        status: "Confirmed",
      })
      .returning();

    return NextResponse.json({ order: createdOrder }, { status: 201 });
  } catch (error) {
    console.error("POST /api/orders error:", error);
    return NextResponse.json(
      { error: "Unable to place your order right now. Please try again." },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const { id, status } = body;

    if (!id || !status) {
      return NextResponse.json(
        { error: "Order ID and status are required." },
        { status: 400 }
      );
    }

    const [updated] = await db
      .update(orders)
      .set({ status: String(status) })
      .where(eq(orders.id, Number(id)))
      .returning();

    return NextResponse.json({ order: updated });
  } catch (error) {
    console.error("PATCH /api/orders error:", error);
    return NextResponse.json(
      { error: "Failed to update order status." },
      { status: 500 }
    );
  }
}
