import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { ensureSeeded } from "@/db/seed-data";
import { asc, eq } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    await ensureSeeded();
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");

    let items;
    if (category && category !== "All") {
      items = await db
        .select()
        .from(products)
        .where(eq(products.category, category))
        .orderBy(asc(products.id));
    } else {
      items = await db.select().from(products).orderBy(asc(products.id));
    }

    return NextResponse.json({ products: items });
  } catch (error) {
    console.error("GET /api/products error:", error);
    return NextResponse.json(
      { error: "Failed to load bakery products." },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureSeeded();
    const body = await request.json();
    const {
      name,
      category,
      description,
      basePrice,
      imageUrl,
      badge,
      servingsInfo,
      leadTime,
      flavors,
    } = body;

    if (!name || !category || !description || basePrice === undefined) {
      return NextResponse.json(
        { error: "Name, category, description, and price are required." },
        { status: 400 }
      );
    }

    const numericPrice = Math.max(1, Math.round(Number(basePrice)));
    const slug =
      name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "") +
      "-" +
      Date.now().toString().slice(-4);

    const [created] = await db
      .insert(products)
      .values({
        name: String(name).trim(),
        slug,
        category: String(category).trim(),
        description: String(description).trim(),
        basePrice: numericPrice,
        imageUrl: imageUrl || "/images/custom-cake.jpg",
        badge: badge || "Artisanal",
        servingsInfo: servingsInfo || "Serves 10–20 guests",
        leadTime: leadTime || "48h Notice",
        flavors: flavors || "Madagascar Vanilla, Belgian Chocolate, Red Velvet",
        featured: true,
      })
      .returning();

    return NextResponse.json({ product: created }, { status: 201 });
  } catch (error) {
    console.error("POST /api/products error:", error);
    return NextResponse.json(
      { error: "Failed to create product." },
      { status: 500 }
    );
  }
}
