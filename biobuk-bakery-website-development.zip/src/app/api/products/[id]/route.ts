import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { ensureSeeded } from "@/db/seed-data";
import { eq } from "drizzle-orm";

export async function PATCH(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureSeeded();
    const { id } = await context.params;
    const productId = Number(id);

    if (!Number.isInteger(productId) || productId <= 0) {
      return NextResponse.json({ error: "Invalid product ID." }, { status: 400 });
    }

    const body = await request.json();
    const updatePayload: Partial<typeof products.$inferInsert> = {};

    if (body.basePrice !== undefined) {
      const parsed = Math.round(Number(body.basePrice));
      if (Number.isNaN(parsed) || parsed < 1 || parsed > 50000) {
        return NextResponse.json(
          { error: "Price must be between $1 and $50,000." },
          { status: 400 }
        );
      }
      updatePayload.basePrice = parsed;
    }

    if (typeof body.name === "string" && body.name.trim()) {
      updatePayload.name = body.name.trim();
    }

    if (typeof body.description === "string" && body.description.trim()) {
      updatePayload.description = body.description.trim();
    }

    if (typeof body.servingsInfo === "string" && body.servingsInfo.trim()) {
      updatePayload.servingsInfo = body.servingsInfo.trim();
    }

    if (typeof body.leadTime === "string" && body.leadTime.trim()) {
      updatePayload.leadTime = body.leadTime.trim();
    }

    if (typeof body.badge === "string" && body.badge.trim()) {
      updatePayload.badge = body.badge.trim();
    }

    if (Object.keys(updatePayload).length === 0) {
      return NextResponse.json(
        { error: "No valid fields provided for update." },
        { status: 400 }
      );
    }

    const [updated] = await db
      .update(products)
      .set(updatePayload)
      .where(eq(products.id, productId))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Product not found." }, { status: 404 });
    }

    return NextResponse.json({ product: updated });
  } catch (error) {
    console.error("PATCH /api/products/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to update product." },
      { status: 500 }
    );
  }
}
