import { db } from "@/db";
import { products, testimonials, orders } from "@/db/schema";
import { ensureSeeded } from "@/db/seed-data";
import { asc, desc } from "drizzle-orm";
import BiobukClientApp from "@/components/BiobukClientApp";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureSeeded();

  const [initialProducts, initialTestimonials, initialOrders] =
    await Promise.all([
      db.select().from(products).orderBy(asc(products.id)),
      db.select().from(testimonials).orderBy(desc(testimonials.createdAt)),
      db.select().from(orders).orderBy(desc(orders.createdAt)).limit(20),
    ]);

  return (
    <BiobukClientApp
      initialProducts={initialProducts}
      initialTestimonials={initialTestimonials}
      initialOrders={initialOrders}
    />
  );
}
