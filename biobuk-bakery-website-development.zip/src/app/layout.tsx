import type { Metadata } from "next";
import type { ReactNode } from "react";
import {
  Cormorant_Garamond,
  Plus_Jakarta_Sans,
  DM_Mono,
} from "next/font/google";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-jakarta",
  display: "swap",
});

const dmMono = DM_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-dm-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "BIOBUK | Haute Pâtisserie & Artisanal Bakery — Baking Happiness, One Treat at a Time",
  description:
    "BIOBUK is a luxury artisanal bakery and custom cake atelier crafting exquisite birthday cakes, wedding cakes, anniversary cakes, cupcakes, brioche doughnuts, gourmet small chops, and French pastries.",
  keywords: [
    "BIOBUK",
    "BIOBUK Bakery",
    "Luxury Cakes",
    "Birthday Cakes",
    "Wedding Cakes",
    "Anniversary Cakes",
    "Cupcakes",
    "Doughnuts",
    "Small Chops",
    "Artisanal Pastries",
    "Custom Cakes",
  ],
  openGraph: {
    title: "BIOBUK — Baking Happiness, One Treat at a Time",
    description:
      "Handcrafted celebration cakes, gourmet small chops, and French viennoiserie baked fresh daily for your sweetest moments.",
    type: "website",
    siteName: "BIOBUK Pâtisserie",
    images: [
      {
        url: "/images/hero-cake.jpg",
        width: 1200,
        height: 800,
        alt: "BIOBUK Signature Tiered Celebration Cake",
      },
    ],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Bakery",
    name: "BIOBUK Haute Pâtisserie & Bakery",
    slogan: "Baking Happiness, One Treat at a Time.",
    description:
      "Artisanal bakery dedicated to making delicious, beautiful cakes, small chops, and pastries for everyday celebrations and special occasions.",
    telephone: "+234 809 246 2850",
    email: "orders@biobukbakery.com",
    address: {
      "@type": "PostalAddress",
      streetAddress: "24 Blossom Atelier Way, Victoria Island",
      addressLocality: "Lagos",
      addressCountry: "NG",
    },
    openingHours: "Mo-Sa 08:00-20:00, Su 10:00-18:00",
    priceRange: "$$",
    servesCuisine: "Cakes, Pastries, Confectionery, Small Chops",
  };

  return (
    <html
      lang="en"
      className={`${cormorant.variable} ${jakarta.variable} ${dmMono.variable} scroll-smooth`}
    >
      <body className="bg-[#FFFBF7] text-[#2C1A14] font-sans antialiased selection:bg-[#FCEEE9] selection:text-[#2C1A14]">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {children}
      </body>
    </html>
  );
}
